# SeQr UWB Warehouse Product Location Tracking POC

This repository is a C-first implementation baseline for the SeQr warehouse UWB POC.

## Governing engineering rules

The implementation follows the supplied SeQr Technology Development Standards:
- production-ready by default
- understand existing architecture before changing it
- security-first
- no secrets in source
- configuration-driven anchors/bins
- minimal/focused changes
- explicit error handling
- logging without sensitive data
- tests for normal/error/boundary/security cases
- backward compatibility
- no invented vendor APIs

Source requirements are based on the supplied:
- `Initial Prompt DWM3001CDK POC`
- `UWB Warehouse Product Location Tracking – POC`

## Important hardware/SDK boundary

The DWM3001CDK firmware is C and is intended to run inside the Qorvo QM33/DW3 SDK project.
The exact vendor API calls depend on the Qorvo SDK package installed by SeQr. Therefore
`firmware/qorvo/dwm3001_adapter.c` is deliberately a hardware integration boundary.

It does NOT invent Qorvo APIs. The adapter returns a clear "not integrated" result until
the exact SDK implementation is connected.

Qorvo's public QM33 SDK repository documents DWM3001CDK builds and uses the nRF52833 target.
The Qorvo forum currently states that an official public DWM3001C TDoA example is not
available; a custom implementation would therefore require the exact vendor/driver
integration and synchronized anchors.

## POC protocol recommendation

Use TWR first:
- Anchor A = fixed
- Anchor B = fixed
- Forklift = mobile tag

Two fixed anchors provide two ranges, but they do not uniquely determine an unrestricted
2-D position. For unrestricted 2-D multilateration, use at least three fixed anchors.
The current three-board POC can therefore validate ranging, workflow, filtering and
collection of ground-truth data; a third fixed anchor should be added for a full 2-D
positioning test.

TDoA is implemented as a protocol-independent C architecture, but it requires:
- 3+ synchronized anchors
- hardware RX timestamps
- clock offset/drift compensation
- sequence correlation
- NLOS/outlier handling
- a multilateration solver

Do not flash the TDoA adapter until those requirements are verified.

## Build host-side tests

Linux/macOS:

    make
    ./build/test_positioning

The host build tests the positioning/filter/bin-selection logic without hardware.

## Raspberry Pi gateway

The gateway reads newline-delimited measurement frames from a serial device and emits
validated measurements to stdout. It is intentionally a small C process so it can be
connected to the final backend through a pipe, Unix socket, HTTP client, MQTT adapter,
or another approved transport without changing the UWB firmware.

Example:

    make gateway
    ./build/uwb_gateway /dev/ttyACM0 115200

The exact USB/UART device depends on the board connection and OS configuration.

## Firmware integration

Copy the application source into the exact Qorvo SDK project used by SeQr and wire:

    firmware/qorvo/dwm3001_adapter.c

to the SDK's DW3110/UWB APIs.

Do not copy vendor SDK source into this repository without checking its license.

Qorvo's public SDK repository:
- See the project links in the generated development documentation.

## Repository layout

    firmware/
      common/
      twr/
      tdoa/
      positioning/
      qorvo/

    raspberry-pi/
      uwb_gateway.c
      positioning/
      configuration/

    backend/
      api/
      database/
      warehouse/

    dashboard/
      index.html

    tests/
      test_positioning.c

## Device configuration

Example configuration is in:
`raspberry-pi/configuration/warehouse.conf.example`

No anchor coordinates or bin IDs are hard-coded in the positioning algorithms.

## Safety / production note

This is a POC foundation, not a claim that the radio adapter is flash-ready without the
actual Qorvo SDK. Hardware integration, RF calibration, security configuration, timing,
NLOS testing, deployment hardening and acceptance testing are required before production.

## Protocol switching and comparison

The project now includes a common protocol-selection layer:

    firmware/common/uwb_protocol_mode.h
    firmware/common/uwb_protocol_engine.h
    firmware/common/uwb_protocol_engine.c

Build the two host-side variants with:

    make test-twr
    make test-tdoa

The same positioning, filtering and bin-identification logic is shared by
both protocol variants.

Use `TEST_PROTOCOLS.md` for the controlled warehouse comparison procedure.
Use `tests/compare_results.py` to compare TWR and TDoA CSV result files.

The TDoA radio adapter remains an integration boundary until the exact
approved Qorvo SDK/DW3110 implementation and anchor synchronization are
connected.
