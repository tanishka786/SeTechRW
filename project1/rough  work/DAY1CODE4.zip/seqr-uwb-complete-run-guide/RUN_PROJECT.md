# SeQr UWB Warehouse POC — v2 Run Instructions

## 1. Purpose

This guide explains how to build and test the latest v2 project containing the TWR/TDoA protocol-selection architecture, positioning layer, Raspberry Pi gateway layer, warehouse/bin logic, tests, and comparison tooling.

**Important:** this is currently a software/host-side POC architecture. It is **not yet a complete flash-ready DWM3001CDK production firmware package**. The actual Qorvo/DWM3001CDK SDK integration must be connected to `firmware/qorvo/dwm3001_adapter.c/.h`.

## 2. Enter the project

```bash
cd seqr-uwb
```

## 3. Required host software

You need:

- C11-compatible C compiler
- GNU Make
- Python 3
- CMake (optional)

Check:

```bash
cc --version
make --version
python3 --version
cmake --version
```

## 4. Run positioning tests

```bash
make clean
make test
```

This runs the host-side positioning tests.

## 5. Test TWR protocol selection

```bash
make clean
make test-twr
```

This builds the selector with:

```c
SEQR_ACTIVE_PROTOCOL=SEQR_PROTOCOL_TWR
```

Expected:

```text
Protocol selection test passed: TWR
```

This verifies the host-side TWR selection path. It does **not** prove that a DWM3001CDK has been flashed or that physical UWB ranging is working.

## 6. Test TDoA protocol selection

```bash
make clean
make test-tdoa
```

This builds the selector with:

```c
SEQR_ACTIVE_PROTOCOL=SEQR_PROTOCOL_TDOA
```

Expected:

```text
Protocol selection test passed: TDoA
```

This verifies the host-side TDoA selection path.

It does **not** prove production TDoA operation. Actual TDoA still requires Qorvo/DW3110 integration, hardware RX timestamps, anchor synchronization, clock offset/drift correction, packet correlation, and production TDoA multilateration.

## 7. Build Raspberry Pi gateway

```bash
make clean
make gateway
```

The gateway executable is produced under `build/`.

The actual physical DWM3001CDK transport must be connected according to the approved hardware/SDK setup.

## 8. Run all host-side checks

```bash
make clean
make test
make gateway
make test-twr
make test-tdoa
```

Successful completion means the current host-side source and tests compile and run. It does not mean the physical warehouse system has been validated.

## 9. CMake alternative

```bash
cmake -S . -B build-cmake
cmake --build build-cmake
```

Typical test executables:

```bash
./build-cmake/test_positioning
./build-cmake/test_protocol_twr
./build-cmake/test_protocol_tdoa
```

## 10. Protocol selection

The selector is:

```text
firmware/common/uwb_protocol_mode.h
```

Available modes:

```c
SEQR_PROTOCOL_TWR
SEQR_PROTOCOL_TDOA
```

TWR is the default.

The common dispatch layer is:

```text
firmware/common/uwb_protocol_engine.h
firmware/common/uwb_protocol_engine.c
```

Use the Make targets rather than manually changing the source for normal tests:

```bash
make test-twr
make test-tdoa
```

## 11. TWR path

```text
Application
    ↓
Protocol Engine
    ↓
TWR Tag / Anchor
    ↓
DWM3001 Adapter
    ↓
Qorvo SDK
    ↓
DWM3001CDK
```

Relevant files:

```text
firmware/twr/twr_tag.c
firmware/twr/twr_tag.h
firmware/twr/twr_anchor.c
firmware/twr/twr_anchor.h
```

## 12. TDoA path

```text
Forklift Tag
    ↓ broadcast beacon
Anchor A / Anchor B / Anchor C
    ↓ RX timestamps
TDoA processing
    ↓
Position
```

Relevant files:

```text
firmware/tdoa/tdoa_tag.c
firmware/tdoa/tdoa_anchor.c
firmware/tdoa/tdoa_solver.c
```

The architecture is selectable, but the real DWM3001CDK TDoA radio implementation still requires the exact Qorvo SDK and hardware synchronization/timestamp implementation.

## 13. DWM3001CDK integration

Hardware-specific code is isolated in:

```text
firmware/qorvo/dwm3001_adapter.c
firmware/qorvo/dwm3001_adapter.h
```

When the exact approved SDK is available, connect:

1. Radio initialization
2. TWR exchange
3. Hardware RX timestamps
4. TDoA anchor synchronization
5. Clock offset/drift correction
6. Packet sequence correlation
7. Real measurements to the positioning layer
8. Physical-board validation

Do not invent vendor API names.

## 14. Raspberry Pi

Main files:

```text
raspberry-pi/uwb_gateway.c
raspberry-pi/positioning/position_engine.c
raspberry-pi/positioning/position_engine.h
raspberry-pi/configuration/warehouse.conf.example
```

Intended flow:

```text
DWM3001CDK
    ↓
UWB Gateway
    ↓
Position Engine
    ↓
Warehouse Backend
```

## 15. Warehouse configuration

Use configuration for:

- Anchor IDs
- Anchor coordinates
- Warehouse dimensions
- Bin IDs
- Bin coordinates
- Manufacturing-machine location
- Coordinate reference system

Do not hard-code production warehouse coordinates into algorithms.

## 16. Product placement workflow

The intended flow is:

```text
Product manufactured
    ↓
Forklift picks product
    ↓
QR/barcode scan
    ↓
Active placement transaction
    ↓
Forklift moves
    ↓
Place/End event
    ↓
Capture final UWB position
    ↓
Determine bin
    ↓
Check confidence/tolerance
    ↓
Assign product → bin
    ↓
Update dashboard
```

The backend/API/dashboard folders provide the architecture, but the production services and physical scanner integration still need implementation.

## 17. Compare TWR and TDoA

After collecting real results:

```bash
python3 tests/compare_results.py twr.csv tdoa.csv
```

CSV fields:

```text
protocol
timestamp
device_id
x_m
y_m
z_m
confidence
position_error_m
packet_count
dropped_packets
invalid_measurements
valid
```

The tool reports:

- Mean error
- Maximum error
- 95th-percentile error
- Error standard deviation
- Mean confidence
- Dropped packets
- Invalid measurements

The included example CSV files are demonstration data only.

You can test them with:

```bash
python3 tests/compare_results.py     tests/example_twr.csv     tests/example_tdoa.csv
```

## 18. Physical warehouse test

After real DWM3001CDK integration, keep these identical for TWR and TDoA:

- Anchor coordinates
- Forklift/tag hardware
- Test positions
- Ground truth
- Filter settings
- Bin configuration
- Test duration
- Test route
- Warehouse conditions

Only change the UWB protocol.

Test:

1. Short distance
2. Medium distance
3. Long distance
4. Tag/forklift orientation
5. Line of sight
6. Partial obstruction
7. NLOS
8. Bin boundaries
9. Between bins
10. Stationary stability
11. Moving forklift
12. Different warehouse areas

Record:

- Actual X/Y/Z
- Calculated X/Y/Z
- Position error
- Expected bin
- Identified bin
- Success/failure
- UWB measurement count
- Confidence
- Timestamp

## 19. Recommended decision metrics

Compare:

- Correct-bin percentage
- 95th-percentile position error
- Mean error
- Maximum error
- Position stability/jitter
- NLOS performance
- Update rate
- Packet loss
- Power consumption

Do not choose the protocol using only mean position error.

## 20. Current limitations

The v2 project is not yet a completed production system.

Still required:

- Actual Qorvo/DWM3001CDK SDK integration
- Physical DWM3001CDK flashing
- Physical TWR validation
- Physical TDoA validation
- Hardware timestamp validation
- Anchor synchronization
- Production backend/API
- Authentication/authorization
- Physical QR/barcode integration
- Live dashboard integration
- Physical accuracy/NLOS testing
- 100-meter coverage evaluation
- Final GO / GO WITH CHANGES / NOT RECOMMENDED decision

## 21. Recommended implementation order

```text
1. Confirm exact Qorvo SDK
2. Integrate DWM3001 adapter
3. Bring up the 3 physical modules
4. Validate TWR ranging
5. Calculate forklift position
6. Add filtering
7. Add configurable anchors/bins
8. Add product scan workflow
9. Add Place/End event
10. Save product → bin
11. Connect dashboard
12. Run accuracy/NLOS tests
13. Implement/validate TDoA
14. Compare TWR vs TDoA
15. Make scaling recommendation
```

## 22. Useful documentation

Read these files in this order:

```text
README.md
PROJECT_FILE_MAP.md
firmware/PROTOCOL_BUILD.md
firmware/qorvo/INTEGRATION.md
TEST_PROTOCOLS.md
```

## 23. Quick start

```bash
cd seqr-uwb

make clean
make test

make test-twr
make test-tdoa

make gateway

python3 tests/compare_results.py     tests/example_twr.csv     tests/example_tdoa.csv
```

## 24. Important distinction

Passing:

```bash
make test
make test-twr
make test-tdoa
make gateway
```

means the host-side software/tests compile and execute.

It does **not** mean:

- DWM3001CDK hardware is validated
- TWR radio operation is production-ready
- TDoA radio operation is production-ready
- 100-meter coverage is proven
- warehouse accuracy is proven

Those require physical hardware integration and controlled warehouse testing.
