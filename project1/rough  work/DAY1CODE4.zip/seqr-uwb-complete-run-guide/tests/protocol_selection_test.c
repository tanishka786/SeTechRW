#include "test_logging.h"
#include "uwb_protocol_mode.h"

#include <assert.h>
#include <stdio.h>

int main(void)
{
    SeqrTestRecord record = {
        .protocol = SEQR_ACTIVE_PROTOCOL,
        .timestamp = 1000U,
        .device_id = 42U,
        .x_m = 10.0,
        .y_m = 20.0,
        .z_m = 3.0,
        .confidence = 0.95,
        .position_error_m = 0.25,
        .packet_count = 100U,
        .dropped_packets = 2U,
        .invalid_measurements = 1U,
        .valid = true
    };

    assert(
        SEQR_ACTIVE_PROTOCOL == SEQR_PROTOCOL_TWR ||
        SEQR_ACTIVE_PROTOCOL == SEQR_PROTOCOL_TDOA);

    assert(seqr_test_logging_write_header());
    assert(seqr_test_logging_write_record(&record));

    (void)printf(
        "Protocol selection test passed: %s\n",
        SEQR_ACTIVE_PROTOCOL == SEQR_PROTOCOL_TWR
            ? "TWR"
            : "TDoA");

    return 0;
}
