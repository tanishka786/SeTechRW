# Tests

Run:

    make
    ./build/test_positioning

The tests cover:
- protocol validation
- valid multilateration
- explicit failure with only two anchors
- filter outlier rejection
- bin acceptance
- bin review-required behavior

Hardware acceptance testing must additionally cover the conditions specified by the POC:
LOS/NLOS, distance, orientation, bin boundaries, stability, maximum error, average error,
and correctly identified-bin percentage.
