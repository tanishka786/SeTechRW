#!/usr/bin/env python3

import csv
import math
import statistics
import sys
from pathlib import Path


def read_records(path):
    with Path(path).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def numeric(records, key):
    values = []
    for record in records:
        try:
            value = float(record[key])
        except (KeyError, TypeError, ValueError):
            continue
        if math.isfinite(value):
            values.append(value)
    return values


def summarize(name, records):
    errors = numeric(records, "position_error_m")
    confidence = numeric(records, "confidence")
    dropped = numeric(records, "dropped_packets")
    invalid = numeric(records, "invalid_measurements")

    valid = sum(1 for row in records if row.get("valid") == "1")

    print(f"\n{name}")
    print("-" * len(name))
    print(f"Samples:              {len(records)}")
    print(f"Valid samples:        {valid}")

    if errors:
        ordered = sorted(errors)
        p95_index = min(
            len(ordered) - 1,
            math.ceil(0.95 * len(ordered)) - 1,
        )
        print(f"Mean error (m):       {statistics.mean(errors):.4f}")
        print(f"Max error (m):        {max(errors):.4f}")
        print(f"95th percentile (m):  {ordered[p95_index]:.4f}")
        if len(errors) > 1:
            print(f"Error stdev (m):      {statistics.stdev(errors):.4f}")

    if confidence:
        print(f"Mean confidence:      {statistics.mean(confidence):.4f}")

    print(f"Dropped packets:      {sum(dropped):.0f}")
    print(f"Invalid measurements: {sum(invalid):.0f}")


def main():
    if len(sys.argv) != 3:
        print(
            "Usage: python3 tests/compare_results.py twr.csv tdoa.csv",
            file=sys.stderr,
        )
        return 2

    twr = read_records(sys.argv[1])
    tdoa = read_records(sys.argv[2])

    summarize("TWR", twr)
    summarize("TDoA", tdoa)

    print("\nUse bin accuracy, NLOS performance, and 95th-percentile error")
    print("as primary warehouse decision metrics.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
