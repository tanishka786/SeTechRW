#include "bin_identifier.h"
#include "filter.h"
#include "multilateration.h"
#include "position_engine.h"
#include "uwb_protocol.h"

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static void test_protocol(void)
{
    SeqrUwbMeasurement in = {
        .anchor_id = 7U,
        .timestamp = 123456U,
        .distance_m = 12.345,
        .quality = 0.95,
        .valid = true
    };

    SeqrUwbMeasurement out;
    char buffer[128];

    assert(seqr_protocol_encode_measurement(&in, buffer, sizeof(buffer)));
    assert(seqr_protocol_decode_measurement(buffer, &out));
    assert(out.anchor_id == in.anchor_id);
    assert(fabs(out.distance_m - in.distance_m) < 1e-5);
    assert(!seqr_protocol_decode_measurement(
        "M,0,1,12.0,0.9\n", &out));
    assert(!seqr_protocol_decode_measurement(
        "M,1,1,-4.0,0.9\n", &out));
}

static void test_multilateration(void)
{
    /*
     * Anchors:
     * A=(0,0), B=(10,0), C=(0,10)
     * Tag=(3,4)
     */
    SeqrAnchor anchors[3] = {
        {.id=1U, .position={0.0,0.0,0.0}, .enabled=true},
        {.id=2U, .position={10.0,0.0,0.0}, .enabled=true},
        {.id=3U, .position={0.0,10.0,0.0}, .enabled=true}
    };

    SeqrUwbMeasurement ranges[3] = {
        {.anchor_id=1U, .distance_m=5.0, .valid=true},
        {.anchor_id=2U, .distance_m=sqrt(65.0), .valid=true},
        {.anchor_id=3U, .distance_m=sqrt(45.0), .valid=true}
    };

    SeqrPositionEstimate result;

    assert(seqr_multilateration_2d(
        anchors, 3U, ranges, 3U, &result));

    assert(result.valid);
    assert(fabs(result.position.x_m - 3.0) < 1e-6);
    assert(fabs(result.position.y_m - 4.0) < 1e-6);
}

static void test_two_anchor_failure(void)
{
    SeqrAnchor anchors[2] = {
        {.id=1U, .position={0.0,0.0,0.0}, .enabled=true},
        {.id=2U, .position={10.0,0.0,0.0}, .enabled=true}
    };

    SeqrUwbMeasurement ranges[2] = {
        {.anchor_id=1U, .distance_m=5.0, .valid=true},
        {.anchor_id=2U, .distance_m=sqrt(65.0), .valid=true}
    };

    SeqrPositionEstimate result;

    assert(!seqr_multilateration_2d(
        anchors, 2U, ranges, 2U, &result));
}

static void test_filter_outlier(void)
{
    SeqrPositionFilter filter;
    SeqrPositionEstimate input;
    SeqrPositionEstimate output;

    seqr_filter_init(&filter, 3U, 5.0);

    input.position.x_m = 1.0;
    input.position.y_m = 1.0;
    input.position.z_m = 0.0;
    input.confidence = 1.0;
    input.valid = true;

    assert(seqr_filter_update(&filter, &input, &output));

    input.position.x_m = 100.0;
    input.position.y_m = 100.0;

    assert(seqr_filter_update(&filter, &input, &output));
    assert(output.position.x_m < 10.0);
}

static void test_bin_selection(void)
{
    SeqrPositionEstimate position = {
        .position = {10.2, 10.1, 0.0},
        .confidence = 0.9,
        .valid = true
    };

    SeqrBin bins[2];

    (void)memset(bins, 0, sizeof(bins));

    (void)snprintf(bins[0].id, sizeof(bins[0].id), "BIN-001");
    bins[0].position.x_m = 10.0;
    bins[0].position.y_m = 10.0;
    bins[0].enabled = true;

    (void)snprintf(bins[1].id, sizeof(bins[1].id), "BIN-002");
    bins[1].position.x_m = 20.0;
    bins[1].position.y_m = 20.0;
    bins[1].enabled = true;

    SeqrBinMatch match;

    assert(seqr_bin_find_nearest(
        &position, bins, 2U, 1.5, &match));

    assert(match.accepted);
    assert(strcmp(match.bin_id, "BIN-001") == 0);

    position.position.x_m = 50.0;
    position.position.y_m = 50.0;

    assert(seqr_bin_find_nearest(
        &position, bins, 2U, 1.5, &match));

    assert(!match.accepted);
}

int main(void)
{
    test_protocol();
    test_multilateration();
    test_two_anchor_failure();
    test_filter_outlier();
    test_bin_selection();

    (void)printf("All SeQr UWB positioning tests passed.\n");
    return 0;
}
