# Dependency and licensing notes

This repository does not copy Qorvo SDK source files.

When integrating `firmware/qorvo/dwm3001_adapter.c`, use the Qorvo SDK already licensed
and approved by SeQr Technology. Preserve the vendor copyright/license headers in any
vendor files added to the firmware project.

Third-party dependencies should be approved before being added. The host-side code in
this repository intentionally uses the C standard library/POSIX interfaces where possible
to keep the POC dependency surface small.
