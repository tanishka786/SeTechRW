PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS anchors
(
    id INTEGER PRIMARY KEY,
    hardware_id TEXT NOT NULL UNIQUE,
    x_m REAL NOT NULL,
    y_m REAL NOT NULL,
    z_m REAL NOT NULL,
    anchor_type TEXT NOT NULL,
    status TEXT NOT NULL,
    configuration_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bins
(
    id TEXT PRIMARY KEY,
    x_m REAL NOT NULL,
    y_m REAL NOT NULL,
    z_m REAL NOT NULL,
    width_m REAL,
    depth_m REAL,
    height_m REAL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products
(
    id TEXT PRIMARY KEY,
    barcode TEXT NOT NULL UNIQUE,
    description TEXT,
    current_bin_id TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(current_bin_id) REFERENCES bins(id)
);

CREATE TABLE IF NOT EXISTS forklifts
(
    id TEXT PRIMARY KEY,
    uwb_device_id TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS placement_transactions
(
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL,
    forklift_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    placed_at TEXT,
    x_m REAL,
    y_m REAL,
    z_m REAL,
    assigned_bin_id TEXT,
    position_error_m REAL,
    confidence REAL,
    status TEXT NOT NULL,
    raw_measurements TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(product_id) REFERENCES products(id),
    FOREIGN KEY(forklift_id) REFERENCES forklifts(id),
    FOREIGN KEY(assigned_bin_id) REFERENCES bins(id)
);

CREATE INDEX IF NOT EXISTS idx_products_current_bin
    ON products(current_bin_id);

CREATE INDEX IF NOT EXISTS idx_placement_product
    ON placement_transactions(product_id);

CREATE INDEX IF NOT EXISTS idx_placement_time
    ON placement_transactions(placed_at);
