# Backend API contract

The API layer is intentionally specified independently of the UWB firmware.

## Product scan

`POST /api/products/scan`

```json
{
  "barcode": "8901234567890",
  "forkliftId": "FL-003"
}
```

Creates/updates the active placement operation.

## Place event

`POST /api/forklift/place`

```json
{
  "productId": "P-10483",
  "forkliftId": "FL-003"
}
```

Server workflow:
1. validate authenticated caller
2. validate active product/forklift relationship
3. retrieve latest valid UWB position
4. apply filtering/quality checks
5. identify candidate bin
6. reject for manual review if confidence/tolerance is insufficient
7. write the placement transaction atomically
8. update product current bin
9. publish dashboard update

## Dashboard

`GET /api/dashboard`

Returns current counts and warehouse objects.

`GET /api/placements/recent`

Returns recent placement transactions.

`GET /api/products/{id}`

Returns current and historical product location.

## Security

The eventual HTTP implementation must:
- authenticate users/devices
- authorize placement/configuration actions server-side
- validate JSON input
- limit request size
- use TLS in production
- never expose stack traces/database errors
- never log secrets
- use parameterized SQL
