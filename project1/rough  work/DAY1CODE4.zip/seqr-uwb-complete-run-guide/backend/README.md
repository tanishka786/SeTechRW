# Backend

The backend is split into:
- `api/` - API contract and transport boundary
- `database/` - SQL schema
- `warehouse/` - pure C bin-identification logic

The POC intentionally keeps the positioning/bin-selection code independent from HTTP and
database code. This makes the core logic unit-testable and allows the final backend stack
to be selected without rewriting UWB algorithms.

A production HTTP service should be implemented using the SeQr-approved server framework
or existing company backend architecture. Do not introduce an HTTP library solely because
this POC needs a demo endpoint.
