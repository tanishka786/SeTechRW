#ifndef SEQR_BIN_IDENTIFIER_H
#define SEQR_BIN_IDENTIFIER_H

#include "uwb_types.h"
#include <stddef.h>

bool seqr_bin_find_nearest(
    const SeqrPositionEstimate *position,
    const SeqrBin *bins,
    size_t bin_count,
    double max_assignment_distance_m,
    SeqrBinMatch *result);

#endif
