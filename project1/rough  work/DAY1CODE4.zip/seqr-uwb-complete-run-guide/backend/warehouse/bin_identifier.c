#include "bin_identifier.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

bool seqr_bin_find_nearest(
    const SeqrPositionEstimate *position,
    const SeqrBin *bins,
    size_t bin_count,
    double max_assignment_distance_m,
    SeqrBinMatch *result)
{
    size_t i;
    double best = HUGE_VAL;
    size_t best_index = 0U;

    if (position == NULL || bins == NULL || result == NULL ||
        !position->valid ||
        bin_count == 0U ||
        max_assignment_distance_m <= 0.0)
    {
        return false;
    }

    (void)memset(result, 0, sizeof(*result));

    for (i = 0U; i < bin_count; ++i)
    {
        const double dx =
            position->position.x_m - bins[i].position.x_m;
        const double dy =
            position->position.y_m - bins[i].position.y_m;
        const double dz =
            position->position.z_m - bins[i].position.z_m;
        const double distance =
            sqrt((dx * dx) + (dy * dy) + (dz * dz));

        if (bins[i].enabled && distance < best)
        {
            best = distance;
            best_index = i;
        }
    }

    if (!isfinite(best))
    {
        return false;
    }

    (void)snprintf(
        result->bin_id,
        sizeof(result->bin_id),
        "%s",
        bins[best_index].id);

    result->distance_m = best;

    if (best > max_assignment_distance_m)
    {
        result->confidence = 0.0;
        result->accepted = false;
        return true;
    }

    result->confidence =
        1.0 - (best / max_assignment_distance_m);

    result->accepted = true;

    return true;
}
