# Complete Project File Map

This package is the complete version of the SeQr UWB warehouse POC discussed in the development conversation.

## Protocol switching files added/required for TWR <-> TDoA

- `firmware/common/uwb_protocol_mode.h` — TWR/TDoA enum and build-time selector.
- `firmware/common/uwb_protocol_engine.h` — common protocol result/interface definitions.
- `firmware/common/uwb_protocol_engine.c` — dispatches initialization and processing to TWR or TDoA.
- `firmware/common/test_logging.h` — common test record definition.
- `firmware/common/test_logging.c` — CSV test output.
- `tests/protocol_selection_test.c` — verifies TWR and TDoA builds separately.
- `tests/compare_results.py` — compares real TWR and TDoA CSV datasets.
- `TEST_PROTOCOLS.md` — controlled warehouse comparison procedure.
- `firmware/PROTOCOL_BUILD.md` — build/selection instructions.

## Firmware

### common/
- `uwb_types.h` — shared data structures.
- `uwb_config.h` — configuration/default constants.
- `uwb_protocol.h/.c` — serial/wire protocol encode/decode.
- `uwb_protocol_mode.h` — protocol selector.
- `uwb_protocol_engine.h/.c` — common TWR/TDoA dispatch layer.
- `test_logging.h/.c` — protocol comparison logging.
- `diagnostics.h/.c` — diagnostic logging.

### twr/
- `twr_tag.h/.c` — mobile tag TWR application.
- `twr_anchor.h/.c` — fixed anchor TWR application.

### tdoa/
- `tdoa_tag.h/.c` — mobile TDoA beacon transmitter.
- `tdoa_anchor.h/.c` — TDoA timestamp receiver.
- `tdoa_solver.h/.c` — TDoA observation validation/conversion boundary.

### positioning/
- `multilateration.h/.c` — anchor measurements to position.
- `filter.h/.c` — smoothing/outlier handling.

### qorvo/
- `dwm3001_adapter.h/.c` — DWM3001C/Qorvo SDK integration boundary.
- `INTEGRATION.md` — exact hardware integration responsibilities.

## Raspberry Pi

- `uwb_gateway.c` — serial/UWB gateway process.
- `positioning/position_engine.h/.c` — host-side positioning coordinator.
- `configuration/warehouse.conf.example` — configurable warehouse/anchor/bin example.

## Backend

- `api/api_contract.md` — API contract.
- `database/schema.sql` — database schema.
- `warehouse/bin_identifier.h/.c` — position-to-bin decision.

## Dashboard

- `dashboard/index.html` — web dashboard foundation.

## Tests

- `test_positioning.c` — positioning/filter/bin tests.
- `protocol_selection_test.c` — TWR/TDoA selector tests.
- `compare_results.py` — real-result comparison.
- `example_twr.csv`, `example_tdoa.csv` — demonstration data only.

## Build

- `Makefile` — strict host-side build/test targets.
- `CMakeLists.txt` — CMake host-side build with TWR/TDoA test targets.

## Important hardware boundary

The selector is implemented, but a TDoA build is not automatically a production-ready DWM3001CDK TDoA firmware image. The exact Qorvo SDK/DW3110 implementation, hardware timestamps, anchor synchronization, clock correction, and production TDoA solver must be integrated and verified before hardware acceptance testing.
