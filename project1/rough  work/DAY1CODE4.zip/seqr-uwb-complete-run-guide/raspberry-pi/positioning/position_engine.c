#include "position_engine.h"
#include "multilateration.h"

#include <string.h>

void seqr_position_engine_init(SeqrPositionEngine *engine)
{
    if (engine == NULL)
    {
        return;
    }

    (void)memset(engine, 0, sizeof(*engine));
}

bool seqr_position_engine_add_anchor(
    SeqrPositionEngine *engine,
    const SeqrAnchor *anchor)
{
    if (engine == NULL || anchor == NULL ||
        engine->anchor_count >= SEQR_MAX_ANCHORS)
    {
        return false;
    }

    engine->anchors[engine->anchor_count] = *anchor;
    engine->anchor_count++;

    return true;
}

bool seqr_position_engine_add_measurement(
    SeqrPositionEngine *engine,
    const SeqrUwbMeasurement *measurement)
{
    if (engine == NULL || measurement == NULL ||
        !measurement->valid ||
        engine->measurement_count >= SEQR_MAX_MEASUREMENTS)
    {
        return false;
    }

    engine->measurements[engine->measurement_count] = *measurement;
    engine->measurement_count++;

    return true;
}

bool seqr_position_engine_calculate(
    const SeqrPositionEngine *engine,
    SeqrPositionEstimate *estimate)
{
    if (engine == NULL || estimate == NULL)
    {
        return false;
    }

    return seqr_multilateration_2d(
        engine->anchors,
        engine->anchor_count,
        engine->measurements,
        engine->measurement_count,
        estimate);
}
