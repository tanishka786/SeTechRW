#ifndef SEQR_POSITION_ENGINE_H
#define SEQR_POSITION_ENGINE_H

#include "uwb_types.h"
#include <stdbool.h>
#include <stddef.h>

typedef struct
{
    SeqrAnchor anchors[SEQR_MAX_ANCHORS];
    size_t anchor_count;

    SeqrUwbMeasurement measurements[SEQR_MAX_MEASUREMENTS];
    size_t measurement_count;
} SeqrPositionEngine;

void seqr_position_engine_init(SeqrPositionEngine *engine);

bool seqr_position_engine_add_anchor(
    SeqrPositionEngine *engine,
    const SeqrAnchor *anchor);

bool seqr_position_engine_add_measurement(
    SeqrPositionEngine *engine,
    const SeqrUwbMeasurement *measurement);

bool seqr_position_engine_calculate(
    const SeqrPositionEngine *engine,
    SeqrPositionEstimate *estimate);

#endif
