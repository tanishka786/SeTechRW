#include "diagnostics.h"
#include "uwb_protocol.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

static bool configure_serial(
    int fd,
    speed_t speed)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) != 0)
    {
        return false;
    }

    cfmakeraw(&tty);

    if (cfsetispeed(&tty, speed) != 0 ||
        cfsetospeed(&tty, speed) != 0)
    {
        return false;
    }

    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= (tcflag_t)~CSTOPB;
    tty.c_cflag &= (tcflag_t)~CRTSCTS;
    tty.c_cflag &= (tcflag_t)~PARENB;
    tty.c_cflag &= (tcflag_t)~CSIZE;
    tty.c_cflag |= CS8;

    return tcsetattr(fd, TCSANOW, &tty) == 0;
}

static void process_line(const char *line)
{
    SeqrUwbMeasurement measurement;

    if (!seqr_protocol_decode_measurement(line, &measurement))
    {
        seqr_log(SEQR_LOG_WARNING, "Rejected invalid UWB frame");
        return;
    }

    /*
     * This is the stable gateway boundary.
     *
     * A production deployment should forward the validated record to the
     * approved backend transport. The gateway does not invent database
     * state or silently discard bad measurements.
     */
    (void)printf(
        "{\"type\":\"uwb_measurement\","
        "\"anchor_id\":%u,"
        "\"timestamp\":%llu,"
        "\"distance_m\":%.6f,"
        "\"quality\":%.6f}\n",
        (unsigned int)measurement.anchor_id,
        (unsigned long long)measurement.timestamp,
        measurement.distance_m,
        measurement.quality);
    (void)fflush(stdout);
}

int main(int argc, char **argv)
{
    int fd;
    char line[256];
    size_t length = 0U;
    speed_t speed = B115200;

    if (argc != 2)
    {
        (void)fprintf(stderr, "Usage: %s /dev/ttyACM0\n", argv[0]);
        return EXIT_FAILURE;
    }

    fd = open(argv[1], O_RDONLY | O_NOCTTY);
    if (fd < 0)
    {
        (void)fprintf(
            stderr,
            "Unable to open %s: %s\n",
            argv[1],
            strerror(errno));
        return EXIT_FAILURE;
    }

    if (!configure_serial(fd, speed))
    {
        (void)fprintf(stderr, "Unable to configure serial port\n");
        (void)close(fd);
        return EXIT_FAILURE;
    }

    seqr_log(SEQR_LOG_INFO, "UWB gateway started");

    for (;;)
    {
        char byte;
        ssize_t received = read(fd, &byte, 1U);

        if (received < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }

            seqr_log(SEQR_LOG_ERROR, "Serial read failed");
            break;
        }

        if (received == 0)
        {
            continue;
        }

        if (byte == '\n')
        {
            line[length] = '\0';
            process_line(line);
            length = 0U;
            continue;
        }

        if (length + 1U >= sizeof(line))
        {
            seqr_log(SEQR_LOG_WARNING, "Oversized serial frame rejected");
            length = 0U;
            continue;
        }

        line[length] = byte;
        length++;
    }

    (void)close(fd);
    return EXIT_FAILURE;
}
