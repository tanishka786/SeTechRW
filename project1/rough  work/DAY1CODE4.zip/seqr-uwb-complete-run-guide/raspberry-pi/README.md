# Raspberry Pi

The Pi is the recommended POC gateway.

Connection:

    DWM3001CDK -- USB/UART --> Raspberry Pi -- Ethernet/Wi-Fi --> Backend

The gateway validates a strict measurement frame and emits JSON to stdout. Connect that
output to the approved backend transport.

Do not expose a raw serial device directly to the public network.
Run the gateway as a restricted service account and apply OS firewall/update controls.
