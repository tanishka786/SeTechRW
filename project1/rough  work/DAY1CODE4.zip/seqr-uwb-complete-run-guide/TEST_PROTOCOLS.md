# TWR vs TDoA comparison procedure

## Goal

Run the same warehouse test using TWR and TDoA and compare stability and
product/bin-location performance.

## Recommended hardware

Use:

- Anchor A
- Anchor B
- Anchor C
- Forklift tag

Three fixed anchors are required for unrestricted 2-D positioning.

## TWR run

    make clean
    make test-twr

Flash the TWR firmware and collect:

    twr.csv

## TDoA run

    make clean
    make test-tdoa

Flash the TDoA firmware and collect:

    tdoa.csv

The TDoA firmware cannot be considered flash-ready until the actual Qorvo
SDK/DW3110 TDoA adapter and anchor synchronization are implemented.

## Keep identical

Do not change:

- anchor coordinates
- test points
- forklift/tag
- ground truth
- filter settings
- bin threshold
- test duration
- route
- warehouse conditions

Only the UWB protocol should change.

## Test cases

1. Static accuracy
2. Static stability/jitter
3. LOS
4. NLOS
5. Forklift/tag orientation
6. Movement
7. Bin-boundary cases
8. Correct-bin percentage

## Record

Each result should contain:

- protocol
- timestamp
- device ID
- X/Y/Z
- confidence
- position error
- packet count
- dropped packets
- invalid measurements
- valid flag

## Compare

    python3 tests/compare_results.py twr.csv tdoa.csv

Primary warehouse KPIs:

1. Correct-bin percentage
2. 95th percentile position error
3. NLOS performance
4. Stability/jitter
5. Update rate
6. Packet loss
7. Power consumption
8. Infrastructure/maintenance complexity
