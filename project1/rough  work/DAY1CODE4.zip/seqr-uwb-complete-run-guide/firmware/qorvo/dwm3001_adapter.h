#ifndef SEQR_DWM3001_ADAPTER_H
#define SEQR_DWM3001_ADAPTER_H

#include "uwb_protocol_engine.h"
#include "uwb_types.h"

#include <stdbool.h>
#include <stdint.h>

typedef enum
{
    SEQR_DWM3001_ROLE_ANCHOR = 1,
    SEQR_DWM3001_ROLE_TAG = 2
} SeqrDwm3001Role;

bool seqr_dwm3001_initialize(SeqrDwm3001Role role);

bool seqr_dwm3001_twr_range(
    uint16_t anchor_id,
    SeqrUwbMeasurement *measurement);

void seqr_dwm3001_process_events(void);

bool seqr_dwm3001_tdoa_tag_initialize(uint16_t tag_id);
bool seqr_dwm3001_tdoa_transmit(uint32_t sequence);

bool seqr_dwm3001_tdoa_anchor_initialize(uint16_t anchor_id);

bool seqr_dwm3001_tdoa_receive(
    SeqrProtocolTdoaObservation *observation);

#endif
