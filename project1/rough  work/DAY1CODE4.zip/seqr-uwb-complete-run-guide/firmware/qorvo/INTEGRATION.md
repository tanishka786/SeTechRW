# Qorvo adapter integration

1. Obtain the exact SeQr-approved Qorvo QM33 SDK version.
2. Open the DWM3001CDK project supplied by that SDK.
3. Add the SeQr application sources.
4. Implement these adapter functions using only APIs that exist in that SDK:
   - `seqr_dwm3001_initialize`
   - `seqr_dwm3001_twr_range`
   - `seqr_dwm3001_process_events`
5. Verify antenna-delay/calibration values with the approved hardware procedure.
6. Build with the SDK's documented ARM toolchain.
7. Flash with the approved J-Link workflow.
8. Run a fixed-distance ranging test before warehouse positioning.

Do not replace failed hardware calls with simulated distance values.

## TWR

For the current POC:
- tag sends/initiates ranging exchange
- anchor responds
- tag obtains a distance
- tag sends the measurement to the gateway

## TDoA

Do not treat the TDoA files as flash-ready firmware. A valid implementation needs:
- 3+ anchors
- synchronization
- hardware RX timestamps
- clock drift/offset handling
- packet sequence correlation
- NLOS handling
- multilateration

The current public Qorvo forum response says there is no public DWM3001C TDoA example.
