#include "filter.h"

#include <math.h>
#include <string.h>

void seqr_filter_init(
    SeqrPositionFilter *filter,
    size_t window_size,
    double max_jump_m)
{
    if (filter == NULL)
    {
        return;
    }

    (void)memset(filter, 0, sizeof(*filter));

    filter->count = 0U;
    filter->next = 0U;
    filter->window_size = 0U;
    filter->max_jump_m = max_jump_m;

    if (window_size == 0U)
    {
        return;
    }

    if (window_size > SEQR_FILTER_MAX_WINDOW)
    {
        window_size = SEQR_FILTER_MAX_WINDOW;
    }

    filter->count = 0U;
    filter->next = 0U;
    filter->window_size = window_size;
}

static size_t capacity(const SeqrPositionFilter *filter)
{
    if (filter == NULL || filter->window_size == 0U)
    {
        return 0U;
    }

    return filter->window_size;
}

bool seqr_filter_update(
    SeqrPositionFilter *filter,
    const SeqrPositionEstimate *input,
    SeqrPositionEstimate *output)
{
    size_t cap;
    size_t i;
    double sx = 0.0;
    double sy = 0.0;
    double sz = 0.0;
    double sc = 0.0;

    if (filter == NULL || input == NULL || output == NULL || !input->valid)
    {
        return false;
    }

    cap = capacity(filter);
    if (cap == 0U)
    {
        return false;
    }

    if (filter->count > 0U)
    {
        const SeqrPositionEstimate *last =
            &filter->samples[(filter->count - 1U) % cap];

        const double dx = input->position.x_m - last->position.x_m;
        const double dy = input->position.y_m - last->position.y_m;
        const double dz = input->position.z_m - last->position.z_m;
        const double jump = sqrt((dx * dx) + (dy * dy) + (dz * dz));

        if (jump > filter->max_jump_m)
        {
            *output = *last;
            return true;
        }
    }

    filter->samples[filter->count % cap] = *input;
    filter->count++;

    {
        size_t used = filter->count < cap ? filter->count : cap;

        for (i = 0U; i < used; ++i)
        {
            sx += filter->samples[i].position.x_m;
            sy += filter->samples[i].position.y_m;
            sz += filter->samples[i].position.z_m;
            sc += filter->samples[i].confidence;
        }

        *output = *input;
        output->position.x_m = sx / (double)used;
        output->position.y_m = sy / (double)used;
        output->position.z_m = sz / (double)used;
        output->confidence = sc / (double)used;
        output->valid = true;
    }

    return true;
}
