#ifndef SEQR_POSITION_FILTER_H
#define SEQR_POSITION_FILTER_H

#include "uwb_types.h"
#include <stddef.h>

#define SEQR_FILTER_MAX_WINDOW 32U

typedef struct
{
    SeqrPositionEstimate samples[SEQR_FILTER_MAX_WINDOW];
    size_t count;
    size_t next;
    size_t window_size;
    double max_jump_m;
} SeqrPositionFilter;

void seqr_filter_init(
    SeqrPositionFilter *filter,
    size_t window_size,
    double max_jump_m);

bool seqr_filter_update(
    SeqrPositionFilter *filter,
    const SeqrPositionEstimate *input,
    SeqrPositionEstimate *output);

#endif
