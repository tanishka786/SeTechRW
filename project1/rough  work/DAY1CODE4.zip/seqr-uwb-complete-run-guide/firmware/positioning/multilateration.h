#ifndef SEQR_MULTILATERATION_H
#define SEQR_MULTILATERATION_H

#include "uwb_types.h"
#include <stddef.h>

bool seqr_multilateration_2d(
    const SeqrAnchor *anchors,
    size_t anchor_count,
    const SeqrUwbMeasurement *measurements,
    size_t measurement_count,
    SeqrPositionEstimate *result);

#endif
