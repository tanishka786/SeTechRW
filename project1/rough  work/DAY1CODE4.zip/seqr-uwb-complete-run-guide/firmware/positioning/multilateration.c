#include "multilateration.h"

#include <math.h>
#include <string.h>

static bool find_range(
    const SeqrUwbMeasurement *measurements,
    size_t count,
    uint16_t anchor_id,
    double *distance_m)
{
    size_t i;

    if (measurements == NULL || distance_m == NULL)
    {
        return false;
    }

    for (i = 0U; i < count; ++i)
    {
        if (measurements[i].valid &&
            measurements[i].anchor_id == anchor_id)
        {
            *distance_m = measurements[i].distance_m;
            return true;
        }
    }

    return false;
}

bool seqr_multilateration_2d(
    const SeqrAnchor *anchors,
    size_t anchor_count,
    const SeqrUwbMeasurement *measurements,
    size_t measurement_count,
    SeqrPositionEstimate *result)
{
    size_t i;
    double r0;
    double a11 = 0.0;
    double a12 = 0.0;
    double a22 = 0.0;
    double b1 = 0.0;
    double b2 = 0.0;
    double determinant;

    if (anchors == NULL || measurements == NULL || result == NULL ||
        anchor_count < 3U || measurement_count < 3U)
    {
        return false;
    }

    (void)memset(result, 0, sizeof(*result));

    if (!find_range(
            measurements,
            measurement_count,
            anchors[0].id,
            &r0))
    {
        return false;
    }

    for (i = 1U; i < anchor_count; ++i)
    {
        double ri;
        double ax;
        double ay;
        double b;

        if (!anchors[i].enabled ||
            !find_range(
                measurements,
                measurement_count,
                anchors[i].id,
                &ri))
        {
            continue;
        }

        ax = 2.0 * (anchors[i].position.x_m - anchors[0].position.x_m);
        ay = 2.0 * (anchors[i].position.y_m - anchors[0].position.y_m);

        b =
            (r0 * r0) -
            (ri * ri) +
            (anchors[i].position.x_m * anchors[i].position.x_m) -
            (anchors[0].position.x_m * anchors[0].position.x_m) +
            (anchors[i].position.y_m * anchors[i].position.y_m) -
            (anchors[0].position.y_m * anchors[0].position.y_m);

        a11 += ax * ax;
        a12 += ax * ay;
        a22 += ay * ay;
        b1 += ax * b;
        b2 += ay * b;
    }

    determinant = (a11 * a22) - (a12 * a12);

    if (fabs(determinant) < 1e-12)
    {
        return false;
    }

    result->position.x_m =
        ((b1 * a22) - (b2 * a12)) / determinant;

    result->position.y_m =
        ((a11 * b2) - (a12 * b1)) / determinant;

    result->position.z_m = anchors[0].position.z_m;
    result->measurements_used = (uint32_t)measurement_count;
    result->confidence = 0.5;
    result->accuracy_m = 0.0;
    result->valid = true;

    /*
     * Residual error gives a more meaningful confidence estimate than
     * a fixed value. This is intentionally conservative for the POC.
     */
    {
        double residual_sum = 0.0;
        size_t used = 0U;

        for (i = 0U; i < anchor_count; ++i)
        {
            double measured;
            double dx;
            double dy;
            double predicted;
            double residual;

            if (!anchors[i].enabled ||
                !find_range(
                    measurements,
                    measurement_count,
                    anchors[i].id,
                    &measured))
            {
                continue;
            }

            dx = result->position.x_m - anchors[i].position.x_m;
            dy = result->position.y_m - anchors[i].position.y_m;
            predicted = sqrt((dx * dx) + (dy * dy));
            residual = fabs(predicted - measured);

            residual_sum += residual * residual;
            used++;
        }

        if (used > 0U)
        {
            result->accuracy_m =
                sqrt(residual_sum / (double)used);

            result->confidence =
                1.0 / (1.0 + result->accuracy_m);
        }
    }

    return true;
}
