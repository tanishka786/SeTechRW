# DWM3001CDK firmware

The firmware is C.

## Roles

### Anchor A / Anchor B

Use the same anchor application and configure a unique device ID and surveyed X/Y/Z
coordinates outside the positioning algorithm.

### Forklift tag

The tag initiates TWR measurements in the POC.

## Why the Qorvo adapter is separate

The exact Qorvo SDK release is not included in the source material. The adapter prevents
the project from inventing vendor APIs. Connect it to the exact approved SDK and preserve
all vendor license headers.

The public Qorvo QM33 SDK repository documents DWM3001CDK build/flash setup and the
nRF52833 target. Use the vendor's actual SDK project rather than replacing its build
system with this host Makefile.
