#ifndef SEQR_TWR_ANCHOR_H
#define SEQR_TWR_ANCHOR_H

#include <stdbool.h>

bool seqr_twr_anchor_initialize(void);
void seqr_twr_anchor_process(void);

#endif
