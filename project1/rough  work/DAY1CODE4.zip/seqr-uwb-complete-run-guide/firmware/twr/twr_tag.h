#ifndef SEQR_TWR_TAG_H
#define SEQR_TWR_TAG_H

#include "uwb_types.h"
#include <stdbool.h>

bool seqr_twr_tag_initialize(void);

bool seqr_twr_tag_range_anchor(
    uint16_t anchor_id,
    SeqrUwbMeasurement *measurement);

#endif
