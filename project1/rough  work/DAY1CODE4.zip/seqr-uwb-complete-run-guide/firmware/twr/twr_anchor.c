#include "twr_anchor.h"
#include "dwm3001_adapter.h"

bool seqr_twr_anchor_initialize(void)
{
    return seqr_dwm3001_initialize(SEQR_DWM3001_ROLE_ANCHOR);
}

void seqr_twr_anchor_process(void)
{
    /*
     * The vendor adapter owns DW3110 RX/TX events.
     * This keeps application code independent of vendor API names.
     */
    seqr_dwm3001_process_events();
}
