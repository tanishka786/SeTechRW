#include "twr_tag.h"
#include "dwm3001_adapter.h"

bool seqr_twr_tag_initialize(void)
{
    return seqr_dwm3001_initialize(SEQR_DWM3001_ROLE_TAG);
}

bool seqr_twr_tag_range_anchor(
    uint16_t anchor_id,
    SeqrUwbMeasurement *measurement)
{
    if (measurement == NULL)
    {
        return false;
    }

    return seqr_dwm3001_twr_range(anchor_id, measurement);
}
