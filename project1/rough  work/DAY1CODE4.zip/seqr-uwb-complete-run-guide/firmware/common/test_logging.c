#include "test_logging.h"

#include <stdio.h>

static const char *protocol_name(SeqrUwbProtocol protocol)
{
    switch (protocol)
    {
        case SEQR_PROTOCOL_TWR:
            return "TWR";

        case SEQR_PROTOCOL_TDOA:
            return "TDoA";

        default:
            return "UNKNOWN";
    }
}

bool seqr_test_logging_write_header(void)
{
    return printf(
        "protocol,timestamp,device_id,x_m,y_m,z_m,confidence,"
        "position_error_m,packet_count,dropped_packets,"
        "invalid_measurements,valid\n") > 0;
}

bool seqr_test_logging_write_record(
    const SeqrTestRecord *record)
{
    if (record == NULL)
    {
        return false;
    }

    return printf(
        "%s,%llu,%u,%.6f,%.6f,%.6f,%.6f,%.6f,%u,%u,%u,%u\n",
        protocol_name(record->protocol),
        (unsigned long long)record->timestamp,
        (unsigned int)record->device_id,
        record->x_m,
        record->y_m,
        record->z_m,
        record->confidence,
        record->position_error_m,
        (unsigned int)record->packet_count,
        (unsigned int)record->dropped_packets,
        (unsigned int)record->invalid_measurements,
        record->valid ? 1U : 0U) > 0;
}
