#ifndef SEQR_TEST_LOGGING_H
#define SEQR_TEST_LOGGING_H

#include "uwb_protocol_mode.h"

#include <stdbool.h>
#include <stdint.h>

typedef struct
{
    SeqrUwbProtocol protocol;
    uint64_t timestamp;
    uint16_t device_id;
    double x_m;
    double y_m;
    double z_m;
    double confidence;
    double position_error_m;
    uint32_t packet_count;
    uint32_t dropped_packets;
    uint32_t invalid_measurements;
    bool valid;
} SeqrTestRecord;

bool seqr_test_logging_write_header(void);

bool seqr_test_logging_write_record(
    const SeqrTestRecord *record);

#endif
