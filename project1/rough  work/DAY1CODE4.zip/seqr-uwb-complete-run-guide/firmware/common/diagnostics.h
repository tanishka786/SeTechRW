#ifndef SEQR_DIAGNOSTICS_H
#define SEQR_DIAGNOSTICS_H

#include <stdarg.h>

typedef enum
{
    SEQR_LOG_DEBUG = 0,
    SEQR_LOG_INFO,
    SEQR_LOG_WARNING,
    SEQR_LOG_ERROR,
    SEQR_LOG_CRITICAL
} SeqrLogLevel;

void seqr_log(SeqrLogLevel level, const char *format, ...);

#endif
