#ifndef SEQR_UWB_PROTOCOL_MODE_H
#define SEQR_UWB_PROTOCOL_MODE_H

/*
 * Build-time protocol selection.
 *
 * Default is TWR. Build the TDoA variant with:
 *   -DSEQR_ACTIVE_PROTOCOL=SEQR_PROTOCOL_TDOA
 */
typedef enum
{
    SEQR_PROTOCOL_TWR = 0,
    SEQR_PROTOCOL_TDOA = 1
} SeqrUwbProtocol;

#ifndef SEQR_ACTIVE_PROTOCOL
#define SEQR_ACTIVE_PROTOCOL SEQR_PROTOCOL_TWR
#endif

#endif
