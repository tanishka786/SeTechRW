#ifndef SEQR_UWB_PROTOCOL_H
#define SEQR_UWB_PROTOCOL_H

#include "uwb_types.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/*
 * Host/gateway wire format:
 *
 *   M,<anchor_id>,<timestamp>,<distance_m>,<quality>\n
 *
 * The parser is deliberately strict. Values outside reasonable ranges
 * are rejected rather than silently accepted.
 */
bool seqr_protocol_encode_measurement(
    const SeqrUwbMeasurement *measurement,
    char *buffer,
    size_t buffer_size);

bool seqr_protocol_decode_measurement(
    const char *line,
    SeqrUwbMeasurement *measurement);

#endif
