#include "uwb_protocol.h"

#include <stdio.h>
#include <string.h>

static bool valid_measurement(const SeqrUwbMeasurement *m)
{
    if (m == NULL)
    {
        return false;
    }

    if (m->anchor_id == 0U)
    {
        return false;
    }

    if (m->distance_m <= 0.0 || m->distance_m > 1000.0)
    {
        return false;
    }

    if (m->quality < 0.0 || m->quality > 1.0)
    {
        return false;
    }

    return true;
}

bool seqr_protocol_encode_measurement(
    const SeqrUwbMeasurement *measurement,
    char *buffer,
    size_t buffer_size)
{
    int written;

    if (!valid_measurement(measurement) || buffer == NULL || buffer_size == 0U)
    {
        return false;
    }

    written = snprintf(
        buffer,
        buffer_size,
        "M,%u,%llu,%.6f,%.6f\n",
        (unsigned int)measurement->anchor_id,
        (unsigned long long)measurement->timestamp,
        measurement->distance_m,
        measurement->quality);

    return written > 0 && (size_t)written < buffer_size;
}

bool seqr_protocol_decode_measurement(
    const char *line,
    SeqrUwbMeasurement *measurement)
{
    unsigned int anchor_id;
    unsigned long long timestamp;
    double distance;
    double quality;
    char extra;

    if (line == NULL || measurement == NULL)
    {
        return false;
    }

    /*
     * The final %c detects unexpected trailing fields.
     */
    if (sscanf(
            line,
            "M,%u,%llu,%lf,%lf %c",
            &anchor_id,
            &timestamp,
            &distance,
            &quality,
            &extra) != 4)
    {
        return false;
    }

    if (anchor_id > UINT16_MAX)
    {
        return false;
    }

    measurement->anchor_id = (uint16_t)anchor_id;
    measurement->timestamp = (uint64_t)timestamp;
    measurement->distance_m = distance;
    measurement->quality = quality;
    measurement->valid = true;

    return valid_measurement(measurement);
}
