#ifndef SEQR_UWB_TYPES_H
#define SEQR_UWB_TYPES_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define SEQR_MAX_ANCHORS 16U
#define SEQR_MAX_BINS 2048U
#define SEQR_MAX_MEASUREMENTS 16U
#define SEQR_DEVICE_ID_MAX 32U

typedef struct
{
    double x_m;
    double y_m;
    double z_m;
} SeqrPosition3D;

typedef struct
{
    uint16_t id;
    SeqrPosition3D position;
    bool enabled;
} SeqrAnchor;

typedef struct
{
    uint16_t anchor_id;
    uint64_t timestamp;
    double distance_m;
    double quality;
    bool valid;
} SeqrUwbMeasurement;

typedef struct
{
    SeqrPosition3D position;
    double accuracy_m;
    double confidence;
    uint32_t measurements_used;
    uint64_t timestamp;
    bool valid;
} SeqrPositionEstimate;

typedef struct
{
    char id[SEQR_DEVICE_ID_MAX];
    SeqrPosition3D position;
    double width_m;
    double depth_m;
    double height_m;
    bool enabled;
} SeqrBin;

typedef struct
{
    char bin_id[SEQR_DEVICE_ID_MAX];
    double distance_m;
    double confidence;
    bool accepted;
} SeqrBinMatch;

#endif
