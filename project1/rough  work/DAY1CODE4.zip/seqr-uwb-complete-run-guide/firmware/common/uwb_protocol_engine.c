#include "uwb_protocol_engine.h"

#include "diagnostics.h"
#include "tdoa_tag.h"
#include "twr_tag.h"

#include <string.h>

static SeqrUwbProtocol g_active_protocol = SEQR_ACTIVE_PROTOCOL;
static uint16_t g_device_id = 0U;

bool seqr_protocol_engine_initialize(
    SeqrUwbProtocol protocol,
    uint16_t device_id)
{
    if (device_id == 0U)
    {
        seqr_log(SEQR_LOG_ERROR, "Invalid device ID");
        return false;
    }

    if (protocol != SEQR_PROTOCOL_TWR &&
        protocol != SEQR_PROTOCOL_TDOA)
    {
        seqr_log(SEQR_LOG_ERROR, "Invalid UWB protocol");
        return false;
    }

    g_active_protocol = protocol;
    g_device_id = device_id;

    switch (g_active_protocol)
    {
        case SEQR_PROTOCOL_TWR:
            return seqr_twr_tag_initialize();

        case SEQR_PROTOCOL_TDOA:
            return seqr_tdoa_tag_initialize(g_device_id);

        default:
            return false;
    }
}

SeqrUwbProtocol seqr_protocol_engine_active_protocol(void)
{
    return g_active_protocol;
}

bool seqr_protocol_engine_process(
    SeqrProtocolResult *result)
{
    if (result == NULL)
    {
        return false;
    }

    (void)memset(result, 0, sizeof(*result));
    result->protocol = g_active_protocol;
    result->device_id = g_device_id;

    switch (g_active_protocol)
    {
        case SEQR_PROTOCOL_TWR:
            /*
             * Production code should obtain the anchor ID from the
             * configured ranging schedule instead of hard-coding 1.
             */
            return seqr_twr_tag_range_anchor(
                1U,
                &result->twr_measurement);

        case SEQR_PROTOCOL_TDOA:
            /*
             * TDoA transmits a beacon. Anchors timestamp its arrival.
             * It does not fabricate a direct distance measurement here.
             */
            return seqr_tdoa_tag_transmit_beacon(0U);

        default:
            return false;
    }
}
