#ifndef SEQR_UWB_CONFIG_H
#define SEQR_UWB_CONFIG_H

#include <stdint.h>

/* All physical values are configuration, not algorithm constants. */
#define SEQR_DEFAULT_MAX_BIN_ASSIGNMENT_DISTANCE_M 1.50
#define SEQR_DEFAULT_FILTER_WINDOW 5U
#define SEQR_DEFAULT_MAX_POSITION_JUMP_M 5.0
#define SEQR_UART_BAUD 115200U

/*
 * These values are protocol/application defaults only.
 * Radio PHY/channel parameters must come from the approved Qorvo SDK
 * configuration for the deployed hardware.
 */
#define SEQR_TWR_MEASUREMENT_PERIOD_MS 100U
#define SEQR_TDOA_BEACON_PERIOD_MS 50U

#endif
