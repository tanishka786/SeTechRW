#ifndef SEQR_UWB_PROTOCOL_ENGINE_H
#define SEQR_UWB_PROTOCOL_ENGINE_H

#include "uwb_protocol_mode.h"
#include "uwb_types.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define SEQR_TDOA_MAX_OBSERVATIONS 16U

typedef struct
{
    uint16_t anchor_id;
    uint16_t tag_id;
    uint32_t sequence;
    uint64_t rx_timestamp;
    bool valid;
} SeqrProtocolTdoaObservation;

typedef struct
{
    SeqrUwbProtocol protocol;
    uint16_t device_id;
    SeqrUwbMeasurement twr_measurement;
    SeqrProtocolTdoaObservation tdoa_observations[
        SEQR_TDOA_MAX_OBSERVATIONS];
    size_t tdoa_observation_count;
} SeqrProtocolResult;

bool seqr_protocol_engine_initialize(
    SeqrUwbProtocol protocol,
    uint16_t device_id);

SeqrUwbProtocol seqr_protocol_engine_active_protocol(void);

bool seqr_protocol_engine_process(
    SeqrProtocolResult *result);

#endif
