#include "diagnostics.h"

#include <stdio.h>
#include <time.h>

static const char *level_name(SeqrLogLevel level)
{
    switch (level)
    {
        case SEQR_LOG_DEBUG: return "DEBUG";
        case SEQR_LOG_INFO: return "INFO";
        case SEQR_LOG_WARNING: return "WARN";
        case SEQR_LOG_ERROR: return "ERROR";
        case SEQR_LOG_CRITICAL: return "CRITICAL";
        default: return "UNKNOWN";
    }
}

void seqr_log(SeqrLogLevel level, const char *format, ...)
{
    time_t now;
    struct tm local_time;
    va_list args;

    if (format == NULL)
    {
        return;
    }

    now = time(NULL);

#if defined(_POSIX_VERSION)
    if (localtime_r(&now, &local_time) == NULL)
    {
        return;
    }
#else
    {
        struct tm *tmp = localtime(&now);
        if (tmp == NULL)
        {
            return;
        }
        local_time = *tmp;
    }
#endif

    (void)fprintf(
        stderr,
        "%04d-%02d-%02dT%02d:%02d:%02d [%s] ",
        local_time.tm_year + 1900,
        local_time.tm_mon + 1,
        local_time.tm_mday,
        local_time.tm_hour,
        local_time.tm_min,
        local_time.tm_sec,
        level_name(level));

    va_start(args, format);
    (void)vfprintf(stderr, format, args);
    va_end(args);

    (void)fputc('\n', stderr);
}
