# TWR / TDoA build selection

The project now has a common protocol-selection layer.

## TWR

    make clean
    make test-twr

The actual Qorvo SDK application should be built with:

    -DSEQR_ACTIVE_PROTOCOL=SEQR_PROTOCOL_TWR

## TDoA

    make clean
    make test-tdoa

The actual Qorvo SDK application should be built with:

    -DSEQR_ACTIVE_PROTOCOL=SEQR_PROTOCOL_TDOA

The selector changes only the protocol path. The filtering, positioning,
bin-identification, database and dashboard layers remain common.

IMPORTANT:
The TDoA radio adapter is not flash-ready until the exact approved Qorvo
SDK/DW3110 implementation, hardware timestamps, anchor synchronization,
clock correction and TDoA solver have been integrated.
