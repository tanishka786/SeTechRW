#include "tdoa_solver.h"

#include <math.h>

#define SEQR_SPEED_OF_LIGHT_MPS 299792458.0

double seqr_tdoa_timestamp_delta_to_distance(
    int64_t delta_ticks,
    double tick_period_seconds)
{
    if (tick_period_seconds <= 0.0)
    {
        return 0.0;
    }

    return (double)delta_ticks *
           tick_period_seconds *
           SEQR_SPEED_OF_LIGHT_MPS;
}

bool seqr_tdoa_validate_observations(
    const SeqrProtocolTdoaObservation *observations,
    size_t count)
{
    size_t i;

    if (observations == NULL || count < 3U)
    {
        return false;
    }

    for (i = 0U; i < count; ++i)
    {
        if (!observations[i].valid ||
            observations[i].tag_id == 0U ||
            observations[i].anchor_id == 0U)
        {
            return false;
        }
    }

    /*
     * This validates packet observations only.
     * A production TDoA solver still needs synchronization,
     * clock drift/offset compensation, timestamp calibration,
     * NLOS handling and hyperbolic multilateration.
     */
    return true;
}
