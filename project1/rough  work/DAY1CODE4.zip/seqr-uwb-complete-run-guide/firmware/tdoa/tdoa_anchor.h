#ifndef SEQR_TDOA_ANCHOR_H
#define SEQR_TDOA_ANCHOR_H

#include "uwb_protocol_engine.h"

#include <stdbool.h>
#include <stdint.h>

bool seqr_tdoa_anchor_initialize(uint16_t anchor_id);

bool seqr_tdoa_anchor_receive(
    SeqrProtocolTdoaObservation *observation);

#endif
