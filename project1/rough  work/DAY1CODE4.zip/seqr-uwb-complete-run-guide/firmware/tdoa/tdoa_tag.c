#include "tdoa_tag.h"
#include "dwm3001_adapter.h"

bool seqr_tdoa_tag_initialize(uint16_t tag_id)
{
    return seqr_dwm3001_tdoa_tag_initialize(tag_id);
}

bool seqr_tdoa_tag_transmit_beacon(uint32_t sequence)
{
    /*
     * The actual TX timestamp must be obtained from the DW3110
     * hardware timestamp mechanism, not a software timer.
     */
    return seqr_dwm3001_tdoa_transmit(sequence);
}
