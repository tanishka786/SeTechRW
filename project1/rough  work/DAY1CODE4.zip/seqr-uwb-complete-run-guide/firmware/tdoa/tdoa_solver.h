#ifndef SEQR_TDOA_SOLVER_H
#define SEQR_TDOA_SOLVER_H

#include "uwb_protocol_engine.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

double seqr_tdoa_timestamp_delta_to_distance(
    int64_t delta_ticks,
    double tick_period_seconds);

bool seqr_tdoa_validate_observations(
    const SeqrProtocolTdoaObservation *observations,
    size_t count);

#endif
