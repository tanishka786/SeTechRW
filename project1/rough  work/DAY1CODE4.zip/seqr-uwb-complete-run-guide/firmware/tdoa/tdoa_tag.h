#ifndef SEQR_TDOA_TAG_H
#define SEQR_TDOA_TAG_H

#include <stdbool.h>
#include <stdint.h>

bool seqr_tdoa_tag_initialize(uint16_t tag_id);
bool seqr_tdoa_tag_transmit_beacon(uint32_t sequence);

#endif
