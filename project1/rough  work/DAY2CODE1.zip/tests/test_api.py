from pathlib import Path
import json
import os
import threading
import urllib.request

from seqr_uwb.config import load_config
from seqr_uwb.database import Database
from seqr_uwb.http_api import ApiServer
from seqr_uwb.logging_setup import configure_logging
from seqr_uwb.service import WarehouseService


def test_dashboard_endpoint(tmp_path):
    cfg_path = tmp_path / "warehouse.toml"
    source = Path("config/warehouse.toml").read_text()
    source = source.replace('environment = "development"', 'environment = "development"')
    cfg_path.write_text(source)
    cfg = load_config(cfg_path)
    db = Database(tmp_path / "warehouse.db")
    logger = configure_logging(tmp_path / "test.log")
    service = WarehouseService(cfg, db, logger)
    dashboard = Path("dashboard/index.html").resolve()
    os.environ["SEQR_API_KEY"] = "test-key"
    server = ApiServer("127.0.0.1", 18081, service, dashboard, "SEQR_API_KEY", logger)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    with urllib.request.urlopen("http://127.0.0.1:18081/api/health", timeout=2) as response:
        payload = json.loads(response.read())
    assert payload["status"] == "ok"
    db.close()
