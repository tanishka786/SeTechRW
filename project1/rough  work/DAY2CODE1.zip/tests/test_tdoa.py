from seqr_uwb.models import Anchor, Position
from seqr_uwb.tdoa import TdoaObservation, solve_tdoa_2d


def test_tdoa_solver_triangle():
    anchors = [Anchor("A", "a", Position(0, 0)), Anchor("B", "b", Position(10, 0)), Anchor("C", "c", Position(0, 10))]
    # Target (3,4): rA=5, rB=sqrt(65), rC=sqrt(45).
    c = 299_792_458.0
    obs = [
        TdoaObservation("A", "B", ((65 ** 0.5) - 5) / c),
        TdoaObservation("A", "C", ((45 ** 0.5) - 5) / c),
    ]
    result = solve_tdoa_2d(anchors, obs)
    assert abs(result.position.x_m - 3) < 1e-3
    assert abs(result.position.y_m - 4) < 1e-3
