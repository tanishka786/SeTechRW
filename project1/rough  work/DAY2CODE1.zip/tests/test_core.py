from seqr_uwb.binning import find_nearest_bin
from seqr_uwb.models import Anchor, Bin, Measurement, Position, PositionEstimate
from seqr_uwb.positioning import PositioningError, multilaterate_2d


def test_multilateration_triangle():
    anchors = [
        Anchor("A", "a", Position(0, 0)),
        Anchor("B", "b", Position(10, 0)),
        Anchor("C", "c", Position(0, 10)),
    ]
    target = Position(3, 4)
    measurements = [
        Measurement("twr", "t", "tag", "A", 5.0),
        Measurement("twr", "t", "tag", "B", (7**2 + 4**2) ** 0.5),
        Measurement("twr", "t", "tag", "C", (3**2 + 6**2) ** 0.5),
    ]
    estimate = multilaterate_2d(anchors, measurements)
    assert abs(estimate.position.x_m - 3) < 1e-6
    assert abs(estimate.position.y_m - 4) < 1e-6


def test_two_anchors_rejected_for_unrestricted_2d():
    anchors = [Anchor("A", "a", Position(0, 0)), Anchor("B", "b", Position(10, 0))]
    measurements = [Measurement("twr", "t", "tag", "A", 5), Measurement("twr", "t", "tag", "B", 5)]
    try:
        multilaterate_2d(anchors, measurements)
    except PositioningError:
        return
    assert False


def test_uncertain_bin_is_not_silently_assigned():
    estimate = PositionEstimate(Position(5, 5), 0.2, 0.2, 3, True)
    bins = [Bin("BIN-001", Position(5, 5))]
    result = find_nearest_bin(estimate, bins, 1.5, 0.4)
    assert result.accepted is False
    assert result.bin_id is None
