# SeQr UWB Warehouse — Python Host Application

This project converts the **host-side warehouse application** from the latest C architecture into Python. It provides:

- configuration-driven anchors and bins;
- TWR/TDoA protocol abstraction;
- 2-D multilateration with a safety check requiring at least 3 fixed anchors;
- position filtering and outlier/jump rejection;
- automatic nearest-bin assignment with confidence/tolerance checks;
- SQLite persistence;
- product scan and Place/End workflow;
- web dashboard and API;
- structured application logging;
- unit/API tests;
- an adapter for the official Qorvo `run_fira_twr.py` output.

## Important hardware boundary

The DWM3001CDK contains the DW3110 UWB transceiver and nRF52833 SoC. Qorvo's supplied quick-start guide states that the board is not preprogrammed and that the UCI firmware must be flashed for UCI-based evaluation. It also documents the Qorvo One TWR GUI, device configuration and calibration flow.

This Python project does **not** invent Qorvo's UCI frames or vendor APIs. For real hardware, use the exact Qorvo SDK supplied/approved by SeQr, flash/configure/calibrate the boards, and point `hardware.qorvo_script` at the SDK's `run_fira_twr.py`. The Python adapter parses the script's ranging-report text and feeds the common positioning pipeline.

For production, the exact multi-anchor FiRa session configuration must be validated against the installed Qorvo SDK before enabling it.

## Software-only smoke test

```bash
python -m seqr_uwb.simulate
```

The simulation is deterministic and is intended to verify the Python pipeline before physical hardware integration.
