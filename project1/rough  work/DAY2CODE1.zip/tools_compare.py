from seqr_uwb.compare import summarize
import argparse

p=argparse.ArgumentParser(description="Compare TWR/TDoA position-error CSV files")
p.add_argument("twr")
p.add_argument("tdoa")
a=p.parse_args()
print("TWR:", summarize(a.twr))
print("TDoA:", summarize(a.tdoa))
