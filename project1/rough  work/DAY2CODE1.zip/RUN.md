# Run Instructions

## 1. Raspberry Pi prerequisites

Recommended Python: 3.11 or newer.

```bash
sudo apt update
sudo apt install -y python3 python3-venv
```

Create an environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 2. Start without hardware first

This validates the dashboard/API/database stack:

```bash
export SEQR_API_KEY='change-this-for-your-PoC'
python -m seqr_uwb.app --config config/warehouse.toml --no-hardware
```

Open:

```text
http://<raspberry-pi-ip>:8080/
```

Use the API key in the dashboard.

Health check:

```bash
curl http://127.0.0.1:8080/api/health
```

## 3. Run tests

```bash
python -m unittest discover -s tests -p 'test_*.py'
```

If `pytest` is installed, the tests can also be run with:

```bash
pytest
```

## 4. Connect the first DWM3001CDK

1. Flash the approved Qorvo UCI firmware using the supplied Qorvo procedure.
2. Configure and calibrate the board.
3. Connect the board's User USB port to the Raspberry Pi.
4. Find its port:

```bash
ls /dev/ttyACM*
```

5. Verify the official Qorvo `run_fira_twr.py` example can communicate with the board.
6. Put the absolute script path and the real serial port into `config/warehouse.toml`.

## 5. Start hardware mode

Set:

```toml
[hardware]
mode = "qorvo_runner"
qorvo_script = "/absolute/path/to/approved/run_fira_twr.py"
```

Configure the source ports/roles/anchor IDs. Then:

```bash
export SEQR_API_KEY='change-this-for-your-PoC'
python -m seqr_uwb.app --config config/warehouse.toml
```

The service will start the configured Qorvo Python source processes, parse successful TWR ranging reports, calculate positions when enough anchor measurements are available, filter them, save them to SQLite, and expose the dashboard/API.

## 6. Product workflow

From the dashboard, enter:

- API key
- Product ID
- QR/barcode
- Forklift ID

Click **Scan / Start**. Then physically move the forklift and place the product. Click **Place / End**.

The backend will:

1. find the active transaction;
2. take the latest valid UWB measurements;
3. calculate the position;
4. filter/reject unsafe jumps;
5. rank bins by distance;
6. require the configured tolerance/confidence;
7. save the product-to-bin assignment, or mark the transaction for review.

## 7. API examples

Start a placement:

```bash
curl -X POST http://127.0.0.1:8080/api/products/scan \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-this-for-your-PoC' \
  -d '{"productId":"P-001","barcode":"QR-001","forkliftId":"FL-001"}'
```

End placement:

```bash
curl -X POST http://127.0.0.1:8080/api/forklift/place \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: change-this-for-your-PoC' \
  -d '{"forkliftId":"FL-001"}'
```

Dashboard data:

```bash
curl http://127.0.0.1:8080/api/dashboard
```

## 8. Logs and database

Runtime files are stored under `runtime/`:

```text
runtime/warehouse.db
runtime/seqr-uwb.log
```

Do not commit these runtime files.

## 9. Before physical acceptance

Run controlled tests for short/medium/long distance, orientations, LOS, obstruction, NLOS, bin boundaries and between-bin positions. Record actual vs calculated position, error, identified/expected bin, confidence, measurement count and timestamp. Use the results to determine whether the architecture is suitable for scaling to the approximately 100 m warehouse.

## 10. Important status

This project is designed to be runnable and testable on a Raspberry Pi, but physical UWB operation depends on the exact Qorvo SDK firmware, calibration, serial port and session configuration. The project deliberately refuses to fabricate vendor behavior when those details are not available.

## 11. Software-only end-to-end smoke test

Before connecting hardware, run:

```bash
python -m seqr_uwb.simulate
```

This uses the configured software anchor geometry, generates deterministic UWB ranges, runs the positioning/filter/bin workflow, and prints the resulting placement record. It is a software test only; it is not a substitute for DWM3001CDK measurements.
