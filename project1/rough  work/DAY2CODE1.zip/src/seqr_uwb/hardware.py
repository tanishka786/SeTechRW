from __future__ import annotations

import re
import subprocess
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from .models import Measurement


@dataclass(frozen=True)
class HardwareSource:
    name: str
    port: str
    role: str
    anchor_id: str


class HardwareError(RuntimeError):
    pass


class QorvoRunnerSource:
    """Runs the approved Qorvo Python ranging example and parses its textual report.

    The source deliberately does not implement or guess Qorvo's private UCI protocol.
    The Qorvo SDK remains responsible for framing/configuration. This adapter consumes
    the documented `run_fira_twr.py` output format (status, MAC address, distance).
    """

    _status = re.compile(r"^\s*status:\s+(.+?)\s+\(0x[0-9a-fA-F]+\)")
    _mac = re.compile(r"^\s*mac address:\s+(.+?)\s*$")
    _distance = re.compile(r"^\s*distance:\s+([-+0-9.]+)\s+cm")
    _sequence = re.compile(r"^\s*sequence n:\s+(\d+)")

    def __init__(self, script: str, source: HardwareSource, on_measurement: Callable[[Measurement], None], logger) -> None:
        if not script:
            raise HardwareError("qorvo_script is empty; set it to the approved SDK run_fira_twr.py")
        self.script = script
        self.source = source
        self.on_measurement = on_measurement
        self.logger = logger
        self._process: subprocess.Popen[str] | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def start(self) -> None:
        command = ["python3", self.script, "-p", self.source.port]
        if self.source.role.lower() == "controlee":
            command.append("--controlee")
        self.logger.info("starting Qorvo source name=%s port=%s role=%s", self.source.name, self.source.port, self.source.role)
        self._process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        self._thread = threading.Thread(target=self._read, name=f"qorvo-{self.source.name}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._process and self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._process.kill()

    def _read(self) -> None:
        status = "unknown"
        mac = ""
        distance_cm: float | None = None
        sequence: int | None = None
        assert self._process is not None and self._process.stdout is not None
        for line in self._process.stdout:
            if self._stop.is_set():
                break
            line = line.rstrip("\n")
            m = self._status.match(line)
            if m:
                status = m.group(1).strip()
            m = self._mac.match(line)
            if m:
                mac = m.group(1).strip()
            m = self._distance.match(line)
            if m:
                distance_cm = float(m.group(1))
            m = self._sequence.match(line)
            if m:
                sequence = int(m.group(1))

            if distance_cm is not None and mac:
                measurement = Measurement(
                    protocol="twr",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    tag_id="forklift-01",
                    anchor_id=self.source.anchor_id,
                    distance_m=distance_cm / 100.0,
                    status="ok" if status.lower() == "ok" else status,
                    sequence=sequence,
                )
                self.on_measurement(measurement)
                status = "unknown"
                mac = ""
                distance_cm = None
                sequence = None
