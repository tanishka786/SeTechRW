from __future__ import annotations

import math
from pathlib import Path

from .config import load_config
from .database import Database
from .logging_setup import configure_logging
from .models import Measurement
from .service import WarehouseService


def main() -> None:
    config = load_config("config/warehouse.toml")
    db = Database(Path("runtime/simulation.db"))
    logger = configure_logging(Path("runtime/simulation.log"))
    service = WarehouseService(config, db, logger)
    target = (10.8, 8.2)
    for anchor in config.anchors:
        distance = math.hypot(target[0] - anchor.position.x_m, target[1] - anchor.position.y_m)
        service.ingest_measurement(Measurement("twr", "simulation", "forklift-01", anchor.id, distance))
    transaction = service.scan_product("SIM-001", "SIM-QR-001", "Simulation product", "FL-001")
    result = service.place("FL-001")
    print({"transactionId": transaction, **result})
    db.close()


if __name__ == "__main__":
    main()
