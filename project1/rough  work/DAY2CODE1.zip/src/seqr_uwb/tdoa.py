from __future__ import annotations

import math
from dataclasses import dataclass

from .models import Anchor, Position, PositionEstimate

SPEED_OF_LIGHT_M_PER_S = 299_792_458.0


@dataclass(frozen=True)
class TdoaObservation:
    reference_anchor_id: str
    anchor_id: str
    delta_time_s: float


def solve_tdoa_2d(anchors: list[Anchor], observations: list[TdoaObservation]) -> PositionEstimate:
    """Solve a basic 2-D TDoA hyperbolic system.

    This is a mathematical host-side solver only. It assumes that the input timestamp
    differences have already been corrected for anchor clock offset/drift and calibrated.
    Those synchronization/correction steps are hardware-system responsibilities and are
    deliberately not fabricated here.
    """
    if len(anchors) < 3 or len(observations) < 2:
        raise ValueError("TDoA 2-D positioning requires at least three anchors and two independent observations")
    by_id = {a.id: a for a in anchors if a.status != "disabled"}
    ref_id = observations[0].reference_anchor_id
    if ref_id not in by_id:
        raise ValueError("TDoA reference anchor is not configured")
    ref = by_id[ref_id]

    # Gauss-Newton from the centroid. The equations are nonlinear; this keeps the solver
    # small and dependency-free while exposing convergence failure explicitly.
    x = sum(a.position.x_m for a in by_id.values()) / len(by_id)
    y = sum(a.position.y_m for a in by_id.values()) / len(by_id)

    for _ in range(30):
        j11 = j12 = j22 = 0.0
        b1 = b2 = 0.0
        used = 0
        r_ref = math.hypot(x - ref.position.x_m, y - ref.position.y_m)
        if r_ref < 1e-9:
            r_ref = 1e-9
        for obs in observations:
            anchor = by_id.get(obs.anchor_id)
            if anchor is None:
                continue
            r_i = math.hypot(x - anchor.position.x_m, y - anchor.position.y_m)
            if r_i < 1e-9:
                r_i = 1e-9
            measured_delta = obs.delta_time_s * SPEED_OF_LIGHT_M_PER_S
            predicted = r_i - r_ref
            residual = measured_delta - predicted
            gx = (x - anchor.position.x_m) / r_i - (x - ref.position.x_m) / r_ref
            gy = (y - anchor.position.y_m) / r_i - (y - ref.position.y_m) / r_ref
            j11 += gx * gx
            j12 += gx * gy
            j22 += gy * gy
            b1 += gx * residual
            b2 += gy * residual
            used += 1
        det = j11 * j22 - j12 * j12
        if used < 2 or abs(det) < 1e-12:
            raise ValueError("TDoA anchor geometry is degenerate")
        dx = (b1 * j22 - b2 * j12) / det
        dy = (j11 * b2 - j12 * b1) / det
        x += dx
        y += dy
        if math.hypot(dx, dy) < 1e-5:
            break
    else:
        raise ValueError("TDoA solver did not converge")

    residuals = []
    r_ref = math.hypot(x - ref.position.x_m, y - ref.position.y_m)
    for obs in observations:
        anchor = by_id.get(obs.anchor_id)
        if anchor is None:
            continue
        predicted = math.hypot(x - anchor.position.x_m, y - anchor.position.y_m) - r_ref
        measured = obs.delta_time_s * SPEED_OF_LIGHT_M_PER_S
        residuals.append(abs(predicted - measured))
    accuracy = math.sqrt(sum(v * v for v in residuals) / len(residuals)) if residuals else math.inf
    confidence = 1.0 / (1.0 + accuracy) if math.isfinite(accuracy) else 0.0
    return PositionEstimate(Position(x, y, ref.position.z_m), confidence, accuracy, len(residuals) + 1, True)
