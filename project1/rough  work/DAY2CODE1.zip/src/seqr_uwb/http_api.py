from __future__ import annotations

import json
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .service import WarehouseService


class ApiServer:
    def __init__(self, host: str, port: int, service: WarehouseService, dashboard_path: Path, api_key_env: str, logger) -> None:
        self.host = host
        self.port = port
        self.service = service
        self.dashboard_path = dashboard_path
        self.api_key_env = api_key_env
        self.logger = logger

    def serve_forever(self) -> None:
        service = self.service
        dashboard_path = self.dashboard_path
        api_key_env = self.api_key_env
        logger = self.logger

        class Handler(BaseHTTPRequestHandler):
            def _json(self, status: int, payload: dict) -> None:
                body = json.dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def _authorized(self) -> bool:
                expected = os.environ.get(api_key_env)
                if not expected:
                    return False
                return self.headers.get("X-API-Key", "") == expected

            def _body(self) -> dict:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 1_000_000:
                    raise ValueError("invalid request body")
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("JSON body must be an object")
                return payload

            def do_GET(self) -> None:  # noqa: N802
                path = urlparse(self.path).path
                try:
                    if path == "/api/health":
                        self._json(HTTPStatus.OK, {"status": "ok"})
                        return
                    if path == "/api/dashboard":
                        self._json(HTTPStatus.OK, service.dashboard())
                        return
                    if path == "/":
                        body = dashboard_path.read_bytes()
                        self.send_response(HTTPStatus.OK)
                        self.send_header("Content-Type", "text/html; charset=utf-8")
                        self.send_header("Content-Length", str(len(body)))
                        self.end_headers()
                        self.wfile.write(body)
                        return
                    self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
                except Exception:
                    logger.exception("GET request failed path=%s", path)
                    self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal_error"})

            def do_POST(self) -> None:  # noqa: N802
                path = urlparse(self.path).path
                if not self._authorized():
                    self._json(HTTPStatus.UNAUTHORIZED, {"error": "authentication_required"})
                    return
                try:
                    payload = self._body()
                    if path == "/api/products/scan":
                        product_id = str(payload.get("productId", "")).strip()
                        barcode = str(payload.get("barcode", "")).strip()
                        forklift_id = str(payload.get("forkliftId", "")).strip()
                        description = payload.get("description")
                        if not product_id or not barcode or not forklift_id:
                            raise ValueError("productId, barcode and forkliftId are required")
                        if any(len(value) > 128 for value in (product_id, barcode, forklift_id)):
                            raise ValueError("productId, barcode and forkliftId must be <= 128 characters")
                        if description is not None and len(str(description)) > 512:
                            raise ValueError("description must be <= 512 characters")
                        transaction_id = service.scan_product(product_id, barcode, description, forklift_id)
                        self._json(HTTPStatus.CREATED, {"transactionId": transaction_id})
                        return
                    if path == "/api/forklift/place":
                        forklift_id = str(payload.get("forkliftId", "")).strip()
                        if not forklift_id:
                            raise ValueError("forkliftId is required")
                        if len(forklift_id) > 128:
                            raise ValueError("forkliftId must be <= 128 characters")
                        self._json(HTTPStatus.OK, service.place(forklift_id))
                        return
                    self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
                except ValueError as exc:
                    self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                except Exception:
                    logger.exception("POST request failed path=%s", path)
                    self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal_error"})

            def log_message(self, fmt: str, *args) -> None:
                logger.info("http " + fmt, *args)

        server = ThreadingHTTPServer((self.host, self.port), Handler)
        logger.info("dashboard/API listening on %s:%s", self.host, self.port)
        server.serve_forever()
