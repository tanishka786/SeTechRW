"""SeQr UWB warehouse tracking application."""
