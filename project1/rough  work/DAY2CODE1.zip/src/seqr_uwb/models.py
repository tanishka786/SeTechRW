from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class Position:
    x_m: float
    y_m: float
    z_m: float = 0.0


@dataclass(frozen=True)
class Anchor:
    id: str
    hardware_id: str
    position: Position
    status: str = "configured"


@dataclass(frozen=True)
class Bin:
    id: str
    position: Position
    width_m: float = 0.0
    depth_m: float = 0.0
    height_m: float = 0.0
    status: str = "available"


@dataclass(frozen=True)
class Measurement:
    protocol: str
    timestamp: str
    tag_id: str
    anchor_id: str
    distance_m: float
    status: str = "ok"
    nlos: Optional[bool] = None
    sequence: Optional[int] = None

    @property
    def valid(self) -> bool:
        return self.status.lower() == "ok" and self.distance_m > 0.0


@dataclass(frozen=True)
class PositionEstimate:
    position: Position
    confidence: float
    accuracy_m: float
    measurements_used: int
    valid: bool


@dataclass(frozen=True)
class BinMatch:
    bin_id: Optional[str]
    distance_m: Optional[float]
    confidence: float
    accepted: bool
    reason: str
