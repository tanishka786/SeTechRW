from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass

from .models import Anchor, Measurement, Position, PositionEstimate


class PositioningError(ValueError):
    """Raised when a position cannot be computed safely."""


def multilaterate_2d(anchors: list[Anchor], measurements: list[Measurement]) -> PositionEstimate:
    valid = {m.anchor_id: m for m in measurements if m.valid}
    enabled = [a for a in anchors if a.status != "disabled"]
    if len(enabled) < 3 or len(valid) < 3:
        raise PositioningError("At least three valid fixed-anchor measurements are required for unrestricted 2-D positioning")

    ref = next((a for a in enabled if a.id in valid), None)
    if ref is None:
        raise PositioningError("No reference anchor has a valid measurement")
    r0 = valid[ref.id].distance_m

    a11 = a12 = a22 = b1 = b2 = 0.0
    used = 0
    for anchor in enabled:
        if anchor.id == ref.id or anchor.id not in valid:
            continue
        ri = valid[anchor.id].distance_m
        ax = 2.0 * (anchor.position.x_m - ref.position.x_m)
        ay = 2.0 * (anchor.position.y_m - ref.position.y_m)
        b = (
            r0 * r0 - ri * ri
            + anchor.position.x_m**2 - ref.position.x_m**2
            + anchor.position.y_m**2 - ref.position.y_m**2
        )
        a11 += ax * ax
        a12 += ax * ay
        a22 += ay * ay
        b1 += ax * b
        b2 += ay * b
        used += 1

    determinant = a11 * a22 - a12 * a12
    if abs(determinant) < 1e-12 or used < 2:
        raise PositioningError("Anchor geometry is degenerate for 2-D positioning")

    x = (b1 * a22 - b2 * a12) / determinant
    y = (a11 * b2 - a12 * b1) / determinant

    residuals = []
    for anchor in enabled:
        measurement = valid.get(anchor.id)
        if measurement is None:
            continue
        predicted = math.hypot(x - anchor.position.x_m, y - anchor.position.y_m)
        residuals.append(abs(predicted - measurement.distance_m))

    accuracy = math.sqrt(sum(v * v for v in residuals) / len(residuals)) if residuals else math.inf
    confidence = 1.0 / (1.0 + accuracy) if math.isfinite(accuracy) else 0.0
    return PositionEstimate(Position(x, y, ref.position.z_m), confidence, accuracy, len(residuals), True)


@dataclass
class PositionFilter:
    window_size: int
    max_jump_m: float

    def __post_init__(self) -> None:
        if self.window_size < 1:
            raise ValueError("window_size must be >= 1")
        if self.max_jump_m <= 0:
            raise ValueError("max_jump_m must be > 0")
        self._history: deque[Position] = deque(maxlen=self.window_size)

    def update(self, estimate: PositionEstimate) -> PositionEstimate:
        if not estimate.valid:
            return estimate
        if self._history:
            previous = self._history[-1]
            jump = math.hypot(estimate.position.x_m - previous.x_m, estimate.position.y_m - previous.y_m)
            if jump > self.max_jump_m:
                return PositionEstimate(previous, min(estimate.confidence, 0.1), jump, estimate.measurements_used, False)
        self._history.append(estimate.position)
        x = sum(p.x_m for p in self._history) / len(self._history)
        y = sum(p.y_m for p in self._history) / len(self._history)
        z = sum(p.z_m for p in self._history) / len(self._history)
        return PositionEstimate(Position(x, y, z), estimate.confidence, estimate.accuracy_m, estimate.measurements_used, True)
