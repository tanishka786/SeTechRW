from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from pathlib import Path

from .config import load_config
from .database import Database
from .hardware import HardwareSource, QorvoRunnerSource
from .http_api import ApiServer
from .logging_setup import configure_logging
from .service import WarehouseService


def main() -> int:
    parser = argparse.ArgumentParser(description="SeQr UWB warehouse tracking service")
    parser.add_argument("--config", default="config/warehouse.toml")
    parser.add_argument("--no-hardware", action="store_true", help="start API/dashboard without starting Qorvo sources")
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    config = load_config(config_path)
    runtime = config_path.parent.parent / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    logger = configure_logging(runtime / "seqr-uwb.log")

    if config.environment == "production" and not os.environ.get(config.api_key_env):
        logger.error("required API key environment variable is not set: %s", config.api_key_env)
        return 2

    db = Database(config.db_path)
    service = WarehouseService(config, db, logger)
    sources = []

    if not args.no_hardware and config.hardware_mode == "qorvo_runner":
        for raw in config.hardware_sources:
            source = HardwareSource(
                name=raw["name"],
                port=raw["port"],
                role=raw["role"],
                anchor_id=raw["anchor_id"],
            )
            runner = QorvoRunnerSource(config.qorvo_script, source, service.ingest_measurement, logger)
            runner.start()
            sources.append(runner)
    elif not args.no_hardware:
        logger.warning("hardware mode '%s' has no active adapter; starting API/dashboard only", config.hardware_mode)

    dashboard = Path(__file__).resolve().parents[2] / "dashboard" / "index.html"
    server = ApiServer(config.api_host, config.api_port, service, dashboard, config.api_key_env, logger)

    def shutdown(*_args) -> None:
        logger.info("shutdown requested")
        for source in sources:
            source.stop()
        db.close()
        raise SystemExit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        server.serve_forever()
    finally:
        for source in sources:
            source.stop()
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
