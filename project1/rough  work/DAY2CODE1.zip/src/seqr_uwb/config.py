from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tomllib
from typing import Any

from .models import Anchor, Bin, Position


@dataclass(frozen=True)
class AppConfig:
    name: str
    environment: str
    protocol: str
    api_host: str
    api_port: int
    api_key_env: str
    db_path: Path
    warehouse_width_m: float
    warehouse_height_m: float
    filter_window: int
    max_jump_m: float
    max_bin_assignment_distance_m: float
    min_confidence: float
    anchors: tuple[Anchor, ...]
    bins: tuple[Bin, ...]
    hardware_mode: str
    qorvo_script: str
    hardware_sources: tuple[dict[str, str], ...]


def _position(data: dict[str, Any]) -> Position:
    return Position(float(data["x_m"]), float(data["y_m"]), float(data.get("z_m", 0.0)))


def load_config(path: str | Path) -> AppConfig:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("rb") as handle:
        raw = tomllib.load(handle)

    app = raw["application"]
    warehouse = raw["warehouse"]
    position = raw["position"]
    database = raw["database"]
    hardware = raw.get("hardware", {})

    anchors = []
    for anchor_id, data in raw.get("anchors", {}).items():
        anchors.append(
            Anchor(
                id=str(anchor_id),
                hardware_id=str(data["hardware_id"]),
                position=_position(data),
                status=str(data.get("status", "configured")),
            )
        )

    bins = []
    for bin_id, data in raw.get("bin", {}).items():
        bins.append(
            Bin(
                id=str(bin_id),
                position=_position(data),
                width_m=float(data.get("width_m", 0.0)),
                depth_m=float(data.get("depth_m", 0.0)),
                height_m=float(data.get("height_m", 0.0)),
                status=str(data.get("status", "available")),
            )
        )

    db_path = Path(database["path"])
    if not db_path.is_absolute():
        db_path = config_path.parent.parent / db_path

    sources = tuple({str(k): str(v) for k, v in source.items()} for source in hardware.get("sources", []))

    return AppConfig(
        name=str(app["name"]),
        environment=str(app["environment"]),
        protocol=str(app["protocol"]).lower(),
        api_host=str(app["api_host"]),
        api_port=int(app["api_port"]),
        api_key_env=str(app["api_key_env"]),
        db_path=db_path,
        warehouse_width_m=float(warehouse["width_m"]),
        warehouse_height_m=float(warehouse["height_m"]),
        filter_window=int(position["filter_window"]),
        max_jump_m=float(position["max_jump_m"]),
        max_bin_assignment_distance_m=float(position["max_bin_assignment_distance_m"]),
        min_confidence=float(position["min_confidence"]),
        anchors=tuple(anchors),
        bins=tuple(bins),
        hardware_mode=str(hardware.get("mode", "none")),
        qorvo_script=str(hardware.get("qorvo_script", "")),
        hardware_sources=sources,
    )
