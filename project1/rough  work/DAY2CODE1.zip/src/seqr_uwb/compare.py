from __future__ import annotations

import csv
import math
from pathlib import Path


def _read(path: Path) -> list[float]:
    values=[]
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if str(row.get("valid", "1")).lower() in {"0", "false", "no"}:
                continue
            try:
                values.append(float(row["position_error_m"]))
            except (KeyError, TypeError, ValueError):
                continue
    return values


def summarize(path: str | Path) -> dict[str, float]:
    values=_read(Path(path))
    if not values:
        return {"samples":0}
    ordered=sorted(values)
    p95=ordered[min(len(ordered)-1, math.ceil(0.95*len(ordered))-1)]
    mean=sum(values)/len(values)
    variance=sum((v-mean)**2 for v in values)/len(values)
    return {"samples":len(values),"mean_error_m":mean,"max_error_m":max(values),"p95_error_m":p95,"stddev_m":math.sqrt(variance)}
