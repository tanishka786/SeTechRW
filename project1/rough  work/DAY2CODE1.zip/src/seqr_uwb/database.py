from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .models import Anchor, Bin, Position, PositionEstimate, utc_now


SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS anchors (
    id TEXT PRIMARY KEY,
    hardware_id TEXT NOT NULL UNIQUE,
    x_m REAL NOT NULL, y_m REAL NOT NULL, z_m REAL NOT NULL,
    status TEXT NOT NULL, configuration_json TEXT,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bins (
    id TEXT PRIMARY KEY,
    x_m REAL NOT NULL, y_m REAL NOT NULL, z_m REAL NOT NULL,
    width_m REAL, depth_m REAL, height_m REAL, status TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    barcode TEXT NOT NULL UNIQUE,
    description TEXT,
    current_bin_id TEXT REFERENCES bins(id),
    status TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS forklifts (
    id TEXT PRIMARY KEY,
    uwb_device_id TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS placement_transactions (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id),
    forklift_id TEXT NOT NULL REFERENCES forklifts(id),
    started_at TEXT NOT NULL, placed_at TEXT,
    x_m REAL, y_m REAL, z_m REAL,
    assigned_bin_id TEXT REFERENCES bins(id),
    position_error_m REAL, confidence REAL,
    status TEXT NOT NULL, raw_measurements TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS position_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tag_id TEXT NOT NULL,
    protocol TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    x_m REAL NOT NULL, y_m REAL NOT NULL, z_m REAL NOT NULL,
    accuracy_m REAL, confidence REAL,
    measurements_used INTEGER NOT NULL,
    raw_measurements TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_bin ON products(current_bin_id);
CREATE INDEX IF NOT EXISTS idx_placements_product ON placement_transactions(product_id);
CREATE INDEX IF NOT EXISTS idx_placements_time ON placement_transactions(placed_at);
CREATE INDEX IF NOT EXISTS idx_samples_tag_time ON position_samples(tag_id, timestamp);
"""


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    def seed_configuration(self, anchors: tuple[Anchor, ...], bins: tuple[Bin, ...]) -> None:
        now = utc_now()
        with self.conn:
            for a in anchors:
                self.conn.execute(
                    """INSERT INTO anchors(id,hardware_id,x_m,y_m,z_m,status,configuration_json,created_at,updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(id) DO UPDATE SET hardware_id=excluded.hardware_id,x_m=excluded.x_m,y_m=excluded.y_m,z_m=excluded.z_m,status=excluded.status,updated_at=excluded.updated_at""",
                    (a.id, a.hardware_id, a.position.x_m, a.position.y_m, a.position.z_m, a.status, "{}", now, now),
                )
            for b in bins:
                self.conn.execute(
                    """INSERT INTO bins(id,x_m,y_m,z_m,width_m,depth_m,height_m,status,created_at,updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(id) DO UPDATE SET x_m=excluded.x_m,y_m=excluded.y_m,z_m=excluded.z_m,width_m=excluded.width_m,depth_m=excluded.depth_m,height_m=excluded.height_m,status=excluded.status,updated_at=excluded.updated_at""",
                    (b.id, b.position.x_m, b.position.y_m, b.position.z_m, b.width_m, b.depth_m, b.height_m, b.status, now, now),
                )

    def ensure_forklift(self, forklift_id: str, uwb_device_id: str) -> None:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """INSERT INTO forklifts(id,uwb_device_id,status,created_at,updated_at) VALUES(?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET uwb_device_id=excluded.uwb_device_id,status=excluded.status,updated_at=excluded.updated_at""",
                (forklift_id, uwb_device_id, "active", now, now),
            )

    def upsert_product(self, product_id: str, barcode: str, description: str | None = None) -> None:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                """INSERT INTO products(id,barcode,description,status,created_at,updated_at) VALUES(?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET barcode=excluded.barcode,description=excluded.description,updated_at=excluded.updated_at""",
                (product_id, barcode, description, "in_transit", now, now),
            )

    def start_placement(self, transaction_id: str, product_id: str, forklift_id: str) -> None:
        now = utc_now()
        with self.conn:
            self.conn.execute(
                "INSERT INTO placement_transactions(id,product_id,forklift_id,started_at,status,created_at) VALUES(?,?,?,?,?,?)",
                (transaction_id, product_id, forklift_id, now, "active", now),
            )

    def latest_active_placement(self, forklift_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM placement_transactions WHERE forklift_id=? AND status='active' ORDER BY started_at DESC LIMIT 1",
            (forklift_id,),
        ).fetchone()

    def finish_placement(self, transaction_id: str, estimate: PositionEstimate, bin_id: str | None, raw_measurements: list[dict[str, Any]], accepted: bool) -> None:
        now = utc_now()
        status = "placed" if accepted else "review_required"
        with self.conn:
            row = self.conn.execute("SELECT product_id FROM placement_transactions WHERE id=?", (transaction_id,)).fetchone()
            if row is None:
                raise ValueError("placement transaction not found")
            self.conn.execute(
                """UPDATE placement_transactions SET placed_at=?,x_m=?,y_m=?,z_m=?,assigned_bin_id=?,position_error_m=?,confidence=?,status=?,raw_measurements=? WHERE id=?""",
                (now, estimate.position.x_m, estimate.position.y_m, estimate.position.z_m, bin_id, estimate.accuracy_m, estimate.confidence, status, json.dumps(raw_measurements), transaction_id),
            )
            if accepted and bin_id:
                self.conn.execute(
                    "UPDATE products SET current_bin_id=?,status='stored',updated_at=? WHERE id=?",
                    (bin_id, now, row["product_id"]),
                )

    def save_position(self, tag_id: str, protocol: str, estimate: PositionEstimate, raw_measurements: list[dict[str, Any]]) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO position_samples(tag_id,protocol,timestamp,x_m,y_m,z_m,accuracy_m,confidence,measurements_used,raw_measurements) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (tag_id, protocol, utc_now(), estimate.position.x_m, estimate.position.y_m, estimate.position.z_m, estimate.accuracy_m, estimate.confidence, estimate.measurements_used, json.dumps(raw_measurements)),
            )

    def dashboard(self) -> dict[str, Any]:
        product_count = self.conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        bin_count = self.conn.execute("SELECT COUNT(*) FROM bins").fetchone()[0]
        forklift_count = self.conn.execute("SELECT COUNT(*) FROM forklifts").fetchone()[0]
        review_count = self.conn.execute("SELECT COUNT(*) FROM placement_transactions WHERE status='review_required'").fetchone()[0]
        anchors = [dict(r) for r in self.conn.execute("SELECT id,x_m,y_m,z_m,status FROM anchors ORDER BY id")]
        bins = [dict(r) for r in self.conn.execute("SELECT id,x_m,y_m,z_m,status FROM bins ORDER BY id")]
        forklifts = []
        latest = self.conn.execute("""SELECT f.id, p.x_m, p.y_m, p.z_m FROM forklifts f LEFT JOIN position_samples p ON p.tag_id=f.uwb_device_id AND p.id=(SELECT MAX(id) FROM position_samples WHERE tag_id=f.uwb_device_id) ORDER BY f.id""").fetchall()
        for row in latest:
            forklifts.append({"id": row["id"], "x": row["x_m"], "y": row["y_m"], "z": row["z_m"]})
        placements = [dict(r) for r in self.conn.execute("""SELECT p.product_id AS productId,p.forklift_id AS forkliftId,p.assigned_bin_id AS binId,p.confidence, p.placed_at AS timestamp FROM placement_transactions p WHERE p.status IN ('placed','review_required') ORDER BY p.placed_at DESC LIMIT 25""")]
        return {
            "productCount": product_count,
            "binCount": bin_count,
            "forkliftCount": forklift_count,
            "reviewRequiredCount": review_count,
            "warehouse": {"anchors": anchors, "bins": bins, "forklifts": forklifts},
            "recentPlacements": placements,
        }
