from __future__ import annotations

import math

from .models import Bin, BinMatch, PositionEstimate


def find_nearest_bin(position: PositionEstimate, bins: list[Bin], max_distance_m: float, min_confidence: float) -> BinMatch:
    if not position.valid:
        return BinMatch(None, None, 0.0, False, "position_invalid")
    candidates = [b for b in bins if b.status != "disabled"]
    if not candidates:
        return BinMatch(None, None, 0.0, False, "no_configured_bins")

    best = None
    best_distance = math.inf
    for bin_item in candidates:
        dx = position.position.x_m - bin_item.position.x_m
        dy = position.position.y_m - bin_item.position.y_m
        # The POC maps bins primarily in warehouse X/Y. Z is retained in the
        # model for future bin-volume/geofencing logic but is not used by the
        # initial nearest-bin rule.
        distance = math.hypot(dx, dy)
        if distance < best_distance:
            best_distance = distance
            best = bin_item

    confidence = max(0.0, 1.0 - best_distance / max_distance_m) if max_distance_m > 0 else 0.0
    confidence = min(confidence, position.confidence)
    accepted = best_distance <= max_distance_m and confidence >= min_confidence
    reason = "accepted" if accepted else "uncertain_position_or_bin_distance"
    return BinMatch(best.id if accepted else None, best_distance, confidence, accepted, reason)
