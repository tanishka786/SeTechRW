from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from threading import Lock

from .models import Measurement


@dataclass
class MeasurementBuffer:
    by_anchor: dict[str, Measurement]


class ProtocolEngine:
    """Common measurement pipeline shared by TWR and future TDoA adapters."""

    def __init__(self, protocol: str) -> None:
        protocol = protocol.lower()
        if protocol not in {"twr", "tdoa"}:
            raise ValueError("protocol must be 'twr' or 'tdoa'")
        self.protocol = protocol
        self._lock = Lock()
        self._buffers: dict[str, MeasurementBuffer] = defaultdict(lambda: MeasurementBuffer({}))

    def ingest(self, measurement: Measurement) -> None:
        if measurement.protocol.lower() != self.protocol:
            return
        with self._lock:
            self._buffers[measurement.tag_id].by_anchor[measurement.anchor_id] = measurement

    def snapshot(self, tag_id: str) -> list[Measurement]:
        with self._lock:
            return list(self._buffers[tag_id].by_anchor.values())
