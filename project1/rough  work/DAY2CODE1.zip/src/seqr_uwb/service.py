from __future__ import annotations

import logging
import uuid
from typing import Any

from .binning import find_nearest_bin
from .config import AppConfig
from .database import Database
from .models import Measurement
from .positioning import PositionFilter, PositioningError, multilaterate_2d
from .protocol import ProtocolEngine


class WarehouseService:
    def __init__(self, config: AppConfig, database: Database, logger: logging.Logger) -> None:
        self.config = config
        self.db = database
        self.logger = logger
        self.protocol = ProtocolEngine(config.protocol)
        self.filter = PositionFilter(config.filter_window, config.max_jump_m)
        self.db.seed_configuration(config.anchors, config.bins)
        self.db.ensure_forklift("FL-001", "forklift-01")

    def ingest_measurement(self, measurement: Measurement) -> None:
        self.protocol.ingest(measurement)
        samples = self.protocol.snapshot(measurement.tag_id)
        try:
            estimate = multilaterate_2d(list(self.config.anchors), samples)
            filtered = self.filter.update(estimate)
            self.db.save_position(measurement.tag_id, self.config.protocol, filtered, [m.__dict__ for m in samples])
            self.logger.info("position calculated tag=%s x=%.3f y=%.3f accuracy=%.3f confidence=%.3f used=%d", measurement.tag_id, filtered.position.x_m, filtered.position.y_m, filtered.accuracy_m, filtered.confidence, filtered.measurements_used)
        except PositioningError as exc:
            self.logger.warning("position unavailable tag=%s reason=%s measurements=%d", measurement.tag_id, exc, len(samples))

    def scan_product(self, product_id: str, barcode: str, description: str | None, forklift_id: str) -> str:
        self.db.upsert_product(product_id, barcode, description)
        transaction_id = str(uuid.uuid4())
        self.db.start_placement(transaction_id, product_id, forklift_id)
        self.logger.info("placement started transaction=%s product=%s forklift=%s", transaction_id, product_id, forklift_id)
        return transaction_id

    def place(self, forklift_id: str) -> dict[str, Any]:
        active = self.db.latest_active_placement(forklift_id)
        if active is None:
            raise ValueError("no active placement transaction for forklift")
        measurements = self.protocol.snapshot("forklift-01")
        estimate = multilaterate_2d(list(self.config.anchors), measurements)
        filtered = self.filter.update(estimate)
        match = find_nearest_bin(filtered, list(self.config.bins), self.config.max_bin_assignment_distance_m, self.config.min_confidence)
        self.db.finish_placement(active["id"], filtered, match.bin_id, [m.__dict__ for m in measurements], match.accepted)
        self.logger.info("placement completed transaction=%s bin=%s accepted=%s reason=%s", active["id"], match.bin_id, match.accepted, match.reason)
        return {
            "transactionId": active["id"],
            "productId": active["product_id"],
            "forkliftId": forklift_id,
            "position": filtered.position.__dict__,
            "accuracyM": filtered.accuracy_m,
            "confidence": match.confidence,
            "binId": match.bin_id,
            "accepted": match.accepted,
            "reason": match.reason,
        }
    def dashboard(self) -> dict[str, Any]:
        data = self.db.dashboard()
        data["warehouse"]["width"] = self.config.warehouse_width_m
        data["warehouse"]["height"] = self.config.warehouse_height_m
        return data

