# Engineering Standards Compliance Notes

This project is structured against the supplied SeQr Technology Development Standards and the supplied UWB Warehouse Product Location Tracking POC.

## Implemented in this conversion

- Modular separation of configuration, hardware adapter, protocol, positioning, bin logic, persistence, API and UI.
- Configuration-driven anchor/bin coordinates.
- No credentials in source; mutating API calls require a server-side API key supplied through an environment variable.
- Input-size validation for HTTP requests and business identifiers.
- Safe parameterized SQLite queries.
- Explicit transaction handling for product placement updates.
- Structured application logs without secrets.
- Explicit error handling with safe HTTP responses.
- Unit tests for normal and failure cases.
- TDoA mathematical solver separated from hardware synchronization.
- No fabricated Qorvo hardware measurements or vendor API calls.
- Runtime data and logs excluded from version control.

## Not yet proven by source code alone

- Actual three-board DWM3001CDK operation.
- Physical RF calibration and ranging accuracy.
- Multi-anchor FiRa session configuration for the installed Qorvo SDK.
- NLOS performance.
- 100 m warehouse coverage.
- Production identity provider / enterprise authentication.
- Production network hardening and TLS termination.
- Final GO / GO WITH CHANGES / NOT RECOMMENDED decision.

These are physical/deployment acceptance activities from the supplied POC and must not be represented as complete merely because the Python process starts.
