# Project Map

```text
seqr-uwb-python/
├── config/warehouse.toml              # all environment/warehouse/hardware configuration
├── dashboard/index.html               # web UI
├── docs/HARDWARE_SETUP.md             # DWM3001CDK + Raspberry Pi setup
├── docs/PROJECT_MAP.md                # this file
├── src/seqr_uwb/
│   ├── app.py                         # process entry point
│   ├── config.py                      # TOML configuration loading
│   ├── models.py                      # typed domain models
│   ├── database.py                    # SQLite schema + persistence
│   ├── hardware.py                    # Qorvo script adapter
│   ├── protocol.py                    # TWR/TDoA protocol boundary
│   ├── positioning.py                 # multilateration + filtering
│   ├── binning.py                     # safe bin identification
│   ├── service.py                     # warehouse workflow orchestration
│   ├── http_api.py                    # REST API + dashboard server
│   └── logging_setup.py               # application logging
├── tests/
│   ├── test_core.py                   # positioning/bin tests
│   └── test_api.py                    # API smoke test
├── README.md                          # overview
├── RUN.md                             # installation/run instructions
├── requirements.txt                   # runtime dependency
└── pyproject.toml                     # package metadata
```
