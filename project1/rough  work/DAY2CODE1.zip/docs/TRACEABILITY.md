# Latest C Project → Python Traceability

| Previous project area | Python replacement |
|---|---|
| `firmware/common/uwb_types.*` | `src/seqr_uwb/models.py` |
| `firmware/common/uwb_protocol.*` | `src/seqr_uwb/protocol.py` |
| `firmware/common/uwb_protocol_mode.h` | `config/warehouse.toml` + `protocol.py` |
| `firmware/common/uwb_protocol_engine.*` | `src/seqr_uwb/protocol.py` + `service.py` |
| `firmware/common/test_logging.*` | `logging_setup.py` + SQLite raw measurement/position records |
| `firmware/twr/*` | `hardware.py` Qorvo TWR runner adapter |
| `firmware/tdoa/*` | `tdoa.py` mathematical host-side solver + protocol boundary |
| `firmware/positioning/multilateration.*` | `positioning.py` |
| `firmware/positioning/filter.*` | `positioning.py::PositionFilter` |
| `firmware/qorvo/dwm3001_adapter.*` | `hardware.py` |
| `raspberry-pi/uwb_gateway.c` | `app.py` + `hardware.py` |
| `raspberry-pi/positioning/*` | `service.py` + `positioning.py` |
| `backend/warehouse/bin_identifier.*` | `binning.py` |
| `backend/database/schema.sql` | `database.py` SQLite schema |
| `backend/api/api_contract.md` | `http_api.py` |
| `dashboard/index.html` | `dashboard/index.html` |
| `tests/test_positioning.c` | `tests/test_core.py` |
| `tests/compare_results.py` | Intended next extension: Python result analysis; raw records are already stored in SQLite |

## Deliberate boundary

The original C project correctly avoided inventing vendor APIs. The Python conversion preserves that principle. The DWM3001CDK is still controlled by the approved Qorvo firmware/SDK; the Python host consumes the Qorvo ranging-tool output rather than reimplementing an undocumented vendor UCI stack.
