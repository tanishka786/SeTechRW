# DWM3001CDK + Raspberry Pi Hardware Setup

## 1. Board roles for the POC

The supplied POC defines:

- DWM3001CDK #1 → Fixed Anchor A at the manufacturing machine
- DWM3001CDK #2 → Fixed Anchor B in the warehouse/bin area
- DWM3001CDK #3 → mobile tag on the forklift

The software is not hard-coded to those three devices and supports additional configured anchors.

## 2. Flashing

The supplied Qorvo Quick Start Guide for QM33SDK-1.0.0 says the DWM3001CDK is not shipped preprogrammed and that UCI firmware must be flashed for UCI evaluation. It describes using the board's on-board Segger J-Link OB and J-Flash Lite, selecting `NRF52833_xxAA` over SWD at 4000 kHz, and flashing the SDK UCI HEX. After flashing, power-cycle the board.

Follow the exact Quick Start Guide and the SDK version approved by SeQr. Do not mix calibration data across incompatible SDK versions.

## 3. Calibration

The supplied Qorvo guide states that first use or an SDK upgrade requires device configuration/calibration and gives the DWM3001CDK calibration file path under the SDK. It also recommends auto calibration because it improves ranging/AoA performance.

Complete calibration before collecting warehouse accuracy data.

## 4. Raspberry Pi USB connection

Use the DWM3001CDK **User USB** connection for the virtual COM/UCI path supported by the Qorvo tools. The Qorvo technical forum distinguishes the J-Link USB connection used for flashing/debugging from the User USB virtual COM path used by the UCI/CLI application.

On Raspberry Pi, identify the port with:

```bash
ls /dev/ttyACM*
dmesg | tail -50
```

Do not assume `/dev/ttyACM0`; configure the actual port in `config/warehouse.toml`.

## 5. Qorvo Python tools

The Qorvo SDK contains Python UCI tooling. Qorvo support has specifically pointed DWM3001CDK users to the `run_fira_twr.py` example under the SDK's `Tools/uwb-qorvo-tools/scripts/fira` tree for retrieving ranging data.

Set:

```toml
[hardware]
mode = "qorvo_runner"
qorvo_script = "/absolute/path/to/run_fira_twr.py"
```

Then configure each measurement source under `[[hardware.sources]]`.

## 6. Do not guess multi-anchor configuration

The exact FiRa session parameters and multi-node arrangement must match the installed Qorvo SDK. The Python host does not fabricate those parameters. First prove one controller/controlee ranging session using the Qorvo tool, then configure the multi-anchor arrangement supported by the approved SDK.

## 7. Two-anchor limitation

The supplied POC describes two fixed anchors plus one mobile tag for the initial POC. Two ranges do not uniquely determine an unrestricted 2-D position. The Python positioning engine therefore refuses to silently calculate an unrestricted 2-D position from fewer than three fixed-anchor measurements.

Use the two-anchor setup to validate ranging/workflow/measurement collection, or add a third fixed anchor for a true 2-D positioning test.
