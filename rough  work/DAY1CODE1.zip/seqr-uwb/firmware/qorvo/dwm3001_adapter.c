#include "dwm3001_adapter.h"
#include "diagnostics.h"

#include <stddef.h>

/*
 * IMPORTANT:
 *
 * This file is intentionally an integration stub, not a fake radio.
 *
 * Define SEQR_QORVO_SDK_INTEGRATED in the actual Qorvo SDK project and
 * replace the function bodies with calls to the exact SDK/DW3110 API
 * available in that approved SDK version.
 *
 * Returning false is safer than returning fabricated measurements.
 */

bool seqr_dwm3001_initialize(SeqrDwm3001Role role)
{
    (void)role;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    seqr_log(
        SEQR_LOG_ERROR,
        "DWM3001 adapter is not connected to the approved Qorvo SDK");
    return false;
#else
    /*
     * Example integration responsibilities:
     * 1. initialize nRF52833 peripherals/RTOS services
     * 2. initialize DW3110
     * 3. apply approved UWB PHY/channel configuration
     * 4. apply approved antenna-delay/calibration values
     * 5. configure role-specific ranging behavior
     *
     * Use only APIs from the installed SDK here.
     */
    return false;
#endif
}

bool seqr_dwm3001_twr_range(
    uint16_t anchor_id,
    SeqrUwbMeasurement *measurement)
{
    (void)anchor_id;
    (void)measurement;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    return false;
#else
    /*
     * Integrate the SDK's approved TWR/FiRa ranging sample here.
     * The result must contain the DW3110 hardware-derived ranging result,
     * not an estimated or simulated value.
     */
    return false;
#endif
}

void seqr_dwm3001_process_events(void)
{
#ifndef SEQR_QORVO_SDK_INTEGRATED
    return;
#else
    /*
     * Pump/process the SDK's radio events here.
     */
#endif
}

bool seqr_dwm3001_tdoa_tag_initialize(uint16_t tag_id)
{
    (void)tag_id;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    return false;
#else
    /*
     * A DWM3001C TDoA implementation is not supplied by this repository.
     * Integrate only after SeQr validates the chosen TDoA design,
     * synchronization mechanism and SDK/driver support.
     */
    return false;
#endif
}

bool seqr_dwm3001_tdoa_transmit(uint32_t sequence)
{
    (void)sequence;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    return false;
#else
    return false;
#endif
}

bool seqr_dwm3001_tdoa_anchor_initialize(uint16_t anchor_id)
{
    (void)anchor_id;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    return false;
#else
    return false;
#endif
}

bool seqr_dwm3001_tdoa_receive(
    SeqrTdoaObservation *observation)
{
    (void)observation;

#ifndef SEQR_QORVO_SDK_INTEGRATED
    return false;
#else
    return false;
#endif
}
