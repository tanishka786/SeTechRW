#ifndef SEQR_TDOA_ANCHOR_H
#define SEQR_TDOA_ANCHOR_H

#include <stdbool.h>
#include <stdint.h>

typedef struct
{
    uint16_t anchor_id;
    uint16_t tag_id;
    uint32_t sequence;
    uint64_t rx_timestamp;
    bool valid;
} SeqrTdoaObservation;

bool seqr_tdoa_anchor_initialize(uint16_t anchor_id);
bool seqr_tdoa_anchor_receive(SeqrTdoaObservation *observation);

#endif
