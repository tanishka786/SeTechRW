#include "tdoa_anchor.h"
#include "dwm3001_adapter.h"

bool seqr_tdoa_anchor_initialize(uint16_t anchor_id)
{
    return seqr_dwm3001_tdoa_anchor_initialize(anchor_id);
}

bool seqr_tdoa_anchor_receive(SeqrTdoaObservation *observation)
{
    if (observation == NULL)
    {
        return false;
    }

    return seqr_dwm3001_tdoa_receive(observation);
}
