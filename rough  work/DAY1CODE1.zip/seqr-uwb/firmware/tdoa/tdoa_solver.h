#ifndef SEQR_TDOA_SOLVER_H
#define SEQR_TDOA_SOLVER_H

#include "uwb_types.h"
#include <stddef.h>
#include <stdint.h>

typedef struct
{
    uint16_t anchor_id;
    uint16_t tag_id;
    uint32_t sequence;
    uint64_t rx_timestamp;
    bool valid;
} SeqrTdoaObservation;

double seqr_tdoa_timestamp_delta_to_distance(
    int64_t delta_ticks,
    double tick_period_seconds);

bool seqr_tdoa_validate_observations(
    const SeqrTdoaObservation *observations,
    size_t count);

#endif
